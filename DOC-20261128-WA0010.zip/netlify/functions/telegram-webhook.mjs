// POST /api/telegram — принимает сообщения бота и отвечает на команды.
// Ответ возвращается прямо в теле webhook, поэтому отдельный запрос к Bot API не нужен.
import { timingSafeEqual } from 'node:crypto';
import { buildReply, webhookSecret } from '../lib/bot.mjs';

const status = (code) => new Response(null, { status: code });

function safeEqual(a, b) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

export default async (request) => {
  if (request.method !== 'POST') return status(405);

  const botToken = process.env.BOT_TOKEN;
  if (!botToken) return status(503);

  const received = request.headers.get('x-telegram-bot-api-secret-token') ?? '';
  if (!safeEqual(received, webhookSecret(botToken))) return status(401);

  let update;
  try { update = await request.json(); } catch { return status(400); }

  // Адрес приложения: URL подставляет Netlify, иначе берём адрес самого запроса.
  const appUrl = new URL('/', process.env.URL || request.url).href;
  const reply = buildReply(update, appUrl);
  return reply ? Response.json(reply) : status(200);
};

export const config = { path: '/api/telegram' };
