// POST /api/verify — подтверждает, что приложение открыто настоящим клиентом Telegram.
// Токен бота берётся только из переменной окружения BOT_TOKEN на хостинге.
import { validateInitData } from '../lib/init-data.mjs';

const reply = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
});

export default async (request) => {
  if (request.method !== 'POST') return reply(405, { ok: false, error: 'method_not_allowed' });

  const botToken = process.env.BOT_TOKEN;
  if (!botToken) return reply(503, { ok: false, error: 'not_configured' });

  const [scheme, initData] = (request.headers.get('authorization') ?? '').split(/ (.*)/s);
  if (scheme !== 'tma' || !initData) return reply(401, { ok: false, error: 'unauthorized' });

  const result = validateInitData(initData, botToken);
  if (!result.ok) return reply(401, { ok: false, error: 'unauthorized' });

  // Наружу отдаём только то, что нужно интерфейсу. initData не логируется.
  return reply(200, { ok: true, user: { id: result.user.id } });
};

export const config = { path: '/api/verify' };
