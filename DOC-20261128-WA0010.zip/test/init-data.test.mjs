import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { validateInitData } from '../netlify/lib/init-data.mjs';
import verify from '../netlify/functions/verify-init-data.mjs';

// Вымышленный токен только для тестов.
const TOKEN = '1000000000:TEST_TOKEN_NOT_REAL';
const NOW = Date.now();

function sign(overrides = {}, token = TOKEN) {
  const fields = {
    auth_date: String(Math.floor(NOW / 1000) - 10),
    query_id: 'AAE1',
    signature: 'abc_-123',
    user: JSON.stringify({ id: 42, first_name: 'Тест & Co' }),
    ...overrides,
  };
  const check = Object.keys(fields).sort().map((k) => `${k}=${fields[k]}`).join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(token).digest();
  const hash = createHmac('sha256', secret).update(check).digest('hex');
  return new URLSearchParams({ ...fields, hash }).toString();
}

test('принимает правильно подписанные данные', () => {
  const result = validateInitData(sign(), TOKEN, { now: NOW });
  assert.equal(result.ok, true);
  assert.equal(result.user.id, 42);
});

test('отклоняет подмену пользователя', () => {
  const tampered = new URLSearchParams(sign());
  tampered.set('user', JSON.stringify({ id: 1 }));
  assert.equal(validateInitData(tampered.toString(), TOKEN, { now: NOW }).reason, 'bad_signature');
});

test('отклоняет подпись чужим токеном', () => {
  assert.equal(validateInitData(sign({}, '2:OTHER'), TOKEN, { now: NOW }).reason, 'bad_signature');
});

test('отклоняет устаревшие и будущие данные', () => {
  for (const shift of [-90000, 3600]) {
    const data = sign({ auth_date: String(Math.floor(NOW / 1000) + shift) });
    assert.equal(validateInitData(data, TOKEN, { now: NOW }).reason, 'expired');
  }
});

test('отклоняет мусор', () => {
  assert.equal(validateInitData('', TOKEN).ok, false);
  assert.equal(validateInitData('user=1', TOKEN).reason, 'no_hash');
  assert.equal(validateInitData(`${sign()}&user=2`, TOKEN).reason, 'duplicate_keys');
  assert.equal(validateInitData('a'.repeat(5000), TOKEN).reason, 'bad_input');
  assert.equal(validateInitData(sign(), '').reason, 'no_token');
});

const call = (init) => verify(new Request('https://example.test/api/verify', init));

test('функция: статусы ответа', async () => {
  delete process.env.BOT_TOKEN;
  assert.equal((await call({ method: 'POST' })).status, 503);
  process.env.BOT_TOKEN = TOKEN;
  assert.equal((await call({ method: 'GET' })).status, 405);
  assert.equal((await call({ method: 'POST' })).status, 401);
  assert.equal((await call({ method: 'POST', headers: { Authorization: 'tma hash=00' } })).status, 401);
  const ok = await call({ method: 'POST', headers: { Authorization: `tma ${sign()}` } });
  assert.equal(ok.status, 200);
  assert.deepEqual(await ok.json(), { ok: true, user: { id: 42 } });
  delete process.env.BOT_TOKEN;
});
