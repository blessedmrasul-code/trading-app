import test from 'node:test';
import assert from 'node:assert/strict';
import { buildReply, webhookSecret, COMMANDS } from '../netlify/lib/bot.mjs';
import webhook from '../netlify/functions/telegram-webhook.mjs';
import { setupBot } from '../scripts/setup-bot.mjs';

// Вымышленный токен только для тестов.
const TOKEN = '1000000000:TEST_TOKEN_NOT_REAL';
const APP = 'https://nexora.example/';
const update = (text, extra = {}) => ({
  update_id: 1,
  message: { chat: { id: 7, type: 'private' }, from: { id: 7, first_name: 'Расул' }, text, ...extra },
});
const buttonUrl = (reply) => reply.reply_markup.inline_keyboard[0][0].web_app.url;

test('каждая команда открывает свой раздел', () => {
  for (const { command, page } of COMMANDS) {
    const reply = buildReply(update(`/${command}`), APP);
    assert.equal(buttonUrl(reply), page === 'home' ? APP : `${APP}?page=${page}`);
    assert.ok(reply.text.length > 0 && reply.text.length <= 4096);
  }
});

test('команды соответствуют правилам Telegram', () => {
  for (const { command, description } of COMMANDS) {
    assert.match(command, /^[a-z0-9_]{1,32}$/);
    assert.ok(description.length >= 1 && description.length <= 256);
  }
});

test('разбор текста', () => {
  assert.match(buildReply(update('/start ref_55'), APP).text, /Привет, Расул/);
  assert.match(buildReply(update('/partners@NexoraMintBot'), APP).text, /startapp=ref_7/);
  assert.match(buildReply(update('привет'), APP).text, /Команды/);
  assert.match(buildReply(update('/constructor'), APP).text, /Команды/);
  assert.equal(buildReply(update('/start@OtherBot'), APP), null);
  assert.equal(buildReply(update('/start', { chat: { id: -1, type: 'group' } }), APP), null);
  assert.equal(buildReply({ update_id: 2 }, APP), null);
});

test('webhook принимает только запросы с секретом', async () => {
  process.env.BOT_TOKEN = TOKEN;
  const call = (secret, body = JSON.stringify(update('/start'))) => webhook(new Request('https://nexora.example/api/telegram', {
    method: 'POST', headers: secret ? { 'x-telegram-bot-api-secret-token': secret } : {}, body,
  }));
  assert.equal((await call()).status, 401);
  assert.equal((await call('wrong')).status, 401);
  assert.equal((await call(webhookSecret(TOKEN), 'не json')).status, 400);
  const ok = await call(webhookSecret(TOKEN));
  assert.equal(ok.status, 200);
  assert.equal((await ok.json()).method, 'sendMessage');
  delete process.env.BOT_TOKEN;
  assert.equal((await call('x')).status, 503);
});

function fakeTelegram(results = {}) {
  const calls = [];
  const defaults = { getMe: { username: 'NexoraMintBot' }, getWebhookInfo: { url: '' }, getMyDescription: { description: '' }, getMyShortDescription: { short_description: 'своё' } };
  const fetchImpl = async (url, init) => {
    const method = url.split('/').pop();
    calls.push([method, JSON.parse(init.body)]);
    return { json: async () => ({ ok: true, result: results[method] ?? defaults[method] ?? true }) };
  };
  return { calls, fetchImpl, methods: () => calls.map(([m]) => m) };
}
const env = { BOT_TOKEN: TOKEN, URL: 'https://nexora.example', CONTEXT: 'production' };
const quiet = () => {};

test('настройка ставит webhook, команды и кнопку меню, не затирая описания', async () => {
  const tg = fakeTelegram();
  assert.equal((await setupBot({ env, fetchImpl: tg.fetchImpl, log: quiet })).ok, true);
  const byName = Object.fromEntries(tg.calls);
  assert.equal(byName.setWebhook.url, 'https://nexora.example/api/telegram');
  assert.equal(byName.setWebhook.secret_token, webhookSecret(TOKEN));
  assert.equal(byName.setChatMenuButton.menu_button.web_app.url, APP);
  assert.equal(byName.setMyCommands.commands.length, COMMANDS.length);
  assert.ok(tg.methods().includes('setMyDescription'));
  assert.ok(!tg.methods().includes('setMyShortDescription'));
});

test('настройка ничего не меняет в рискованных случаях', async () => {
  for (const [results, overrides] of [
    [{ getMe: { username: 'AnotherBot' } }, {}],
    [{ getWebhookInfo: { url: 'https://other.example/hook' } }, {}],
    [{}, { CONTEXT: 'deploy-preview' }],
    [{}, { BOT_TOKEN: '' }],
  ]) {
    const tg = fakeTelegram(results);
    assert.equal((await setupBot({ env: { ...env, ...overrides }, fetchImpl: tg.fetchImpl, log: quiet })).ok, false);
    assert.ok(!tg.methods().some((m) => m.startsWith('set')));
  }
});

test('токен не попадает в журнал при ошибке', async () => {
  const lines = [];
  const result = await setupBot({ env, log: (l) => lines.push(l), fetchImpl: async (url) => { throw new Error(url); } });
  assert.equal(result.ok, false);
  assert.ok(!lines.join().includes(TOKEN));
});
