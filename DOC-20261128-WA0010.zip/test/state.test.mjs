import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore, dayKey, PENDING_MS } from '../public/js/state.js';
import { allocate } from '../public/js/views/portfolio.js';
import { html } from '../public/js/ui.js';

const memory = () => {
  const data = new Map();
  return { getItem: (k) => data.get(k) ?? null, setItem: (k, v) => data.set(k, v) };
};

test('начальный баланс равен сумме выполненных операций', () => {
  const store = createStore('t', memory());
  assert.equal(store.totals().balance, 12500);
  assert.equal(store.history(90).at(-1).value, 12500);
});

test('проверка суммы', () => {
  const store = createStore('t', memory());
  for (const bad of ['', '99', 'abc', '-500', '1e5', '100.555', '1000001']) {
    assert.ok(store.validateAmount('deposit', bad).error, bad);
  }
  assert.equal(store.validateAmount('deposit', '1 000,50').amount, 1000.5);
  assert.ok(store.validateAmount('withdraw', '12501').error);
});

test('заявка на вывод резервирует средства и выполняется после задержки', () => {
  const store = createStore('t', memory());
  const { op } = store.createOp('withdraw', '12000', 'Демо');
  assert.equal(store.totals().balance, 12500);
  assert.equal(store.totals().available, 500);
  assert.ok(store.createOp('withdraw', '600', 'Демо').error);
  assert.equal(store.settle(op.ts + 10).length, 0);
  assert.equal(store.settle(op.ts + PENDING_MS).length, 1);
  assert.equal(store.totals().balance, 500);
});

test('отменённая заявка не меняет баланс', () => {
  const store = createStore('t', memory());
  const { op } = store.createOp('deposit', '500', 'Демо');
  assert.equal(store.cancelOp(op.id), true);
  store.settle(op.ts + PENDING_MS);
  assert.equal(store.totals().balance, 12500);
});

test('отметка и награда за задание выдаются один раз', () => {
  const store = createStore('t', memory());
  assert.equal(store.checkin(), 10);
  assert.equal(store.checkin(), 0);
  assert.equal(store.claimTask('vip'), 0);
  store.markTask('vip');
  assert.equal(store.claimTask('vip'), 20);
  assert.equal(store.claimTask('vip'), 0);
  assert.equal(store.state.points, 150);
});

test('серия продолжается после вчерашней отметки и сбрасывается после пропуска', () => {
  const store = createStore('t', memory());
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  Object.assign(store.state, { streak: 7, lastCheckin: dayKey(yesterday.getTime()) });
  assert.deepEqual([store.checkinStatus().index, store.checkinStatus().reward], [0, 10]);
  Object.assign(store.state, { streak: 3, lastCheckin: '2000-01-01' });
  assert.equal(store.checkinStatus().streak, 0);
});

test('данные переживают перезапуск, повреждённые заменяются начальными', () => {
  const storage = memory();
  createStore('t', storage).checkin();
  assert.equal(createStore('t', storage).state.points, 130);
  storage.setItem('t', '{"version":1,"ops":[{"amount":"x"}]}');
  assert.equal(createStore('t', storage).totals().balance, 12500);
  storage.setItem('t', 'не json');
  assert.equal(createStore('t', storage).state.points, 120);
});

test('распределение портфеля сходится с балансом', () => {
  for (const balance of [0, 0.01, 100, 12500, 999999.99]) {
    const total = allocate(balance).reduce((sum, a) => sum + Math.round(a.value * 100), 0);
    assert.equal(total, Math.round(balance * 100));
  }
});

test('шаблоны экранируют пользовательские данные', () => {
  const name = '<img src=x onerror=alert(1)>"\'';
  const output = String(html`<b title="${name}">${name}</b>`);
  assert.ok(!output.includes('<img'));
  assert.ok(output.includes('&lt;img'));
});
