// Настраивает бота при каждой production-сборке на Netlify:
// webhook, меню команд, кнопку меню и описания. Токен никуда не выводится.
import { pathToFileURL } from 'node:url';
import { BOT_USERNAME, COMMANDS, DESCRIPTION, SHORT_DESCRIPTION, webhookSecret } from '../netlify/lib/bot.mjs';

export async function setupBot({ env = process.env, fetchImpl = fetch, log = console.log } = {}) {
  const { BOT_TOKEN: token, URL: siteUrl, CONTEXT: context } = env;
  const skip = (reason) => { log(`Настройка бота пропущена: ${reason}`); return { ok: false, reason }; };

  if (context && context !== 'production') return skip('это не production-сборка');
  if (!token) return skip('не задана переменная BOT_TOKEN');
  if (!siteUrl?.startsWith('https://')) return skip('нет HTTPS-адреса сайта (переменная URL)');

  const call = async (method, body = {}) => {
    let data;
    try {
      const response = await fetchImpl(`https://api.telegram.org/bot${token}/${method}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(15000),
      });
      data = await response.json();
    } catch {
      // Текст исходной ошибки может содержать адрес с токеном, поэтому не выводим его.
      throw new Error(`${method}: нет связи с Telegram`);
    }
    if (!data.ok) throw new Error(`${method}: ${data.description}`);
    return data.result;
  };

  try {
    const me = await call('getMe');
    if (me.username?.toLowerCase() !== BOT_USERNAME.toLowerCase()) {
      return skip(`токен принадлежит другому боту (@${me.username}), ожидается @${BOT_USERNAME}`);
    }

    const appUrl = new URL('/', siteUrl).href;
    const webhookUrl = new URL('/api/telegram', siteUrl).href;

    // Не перехватываем бота у другого сервера без явного разрешения.
    const current = await call('getWebhookInfo');
    if (current.url && current.url !== webhookUrl && env.BOT_WEBHOOK_REPLACE !== '1') {
      return skip(`у бота уже есть webhook на ${new URL(current.url).host}. `
        + 'Чтобы заменить его, добавьте переменную BOT_WEBHOOK_REPLACE=1');
    }

    await call('setWebhook', { url: webhookUrl, secret_token: webhookSecret(token), allowed_updates: ['message'] });
    await call('setMyCommands', { commands: COMMANDS.map(({ command, description }) => ({ command, description })) });
    await call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'NEXORA', web_app: { url: appUrl } } });

    // Описания заполняем, только если они пустые: свои тексты не затираются.
    if (!(await call('getMyDescription')).description) await call('setMyDescription', { description: DESCRIPTION });
    if (!(await call('getMyShortDescription')).short_description) {
      await call('setMyShortDescription', { short_description: SHORT_DESCRIPTION });
    }

    log(`Бот @${BOT_USERNAME} настроен. Приложение: ${appUrl}`);
    return { ok: true, appUrl };
  } catch (error) {
    // Сайт всё равно должен опубликоваться.
    return skip(error.message);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) await setupBot();
