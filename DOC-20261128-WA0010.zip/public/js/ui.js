// Мелкие помощники интерфейса: безопасные шаблоны, форматирование, иконки, шторка, уведомления.

class Safe {
  constructor(value) { this.value = value; }
  toString() { return this.value; }
}

const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escape = (value) => String(value).replace(/[&<>"']/g, (c) => ESCAPES[c]);

function render(value) {
  if (value instanceof Safe) return value.value;
  if (Array.isArray(value)) return value.map(render).join('');
  if (value === null || value === undefined || value === false) return '';
  return escape(value);
}

/** Шаблон, который экранирует все подстановки, кроме вложенных html``. */
export const html = (strings, ...values) => new Safe(
  strings.reduce((out, s, i) => out + s + (i < values.length ? render(values[i]) : ''), ''),
);

export const mount = (element, content) => { element.innerHTML = String(content); };

const money = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });
export const rub = (n) => `${money.format(n)} ₽`;
export const signedRub = (op) => `${op.type === 'deposit' ? '+' : '−'}${rub(op.amount)}`;
export const percent = (n) => `${n > 0 ? '+' : n < 0 ? '−' : ''}${Math.abs(n).toFixed(1).replace('.', ',')}%`;

const dateShort = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' });
const dateFull = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
export const shortDate = (ts) => dateShort.format(ts).replace('.', '');
export const fullDate = (ts) => dateFull.format(ts);

export function plural(n, one, few, many) {
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return many;
  if (b === 1) return one;
  return b > 1 && b < 5 ? few : many;
}

const ICONS = {
  home: '<path d="M3.5 10.5 12 3.8l8.5 6.7"/><path d="M5.5 9.8v10h5v-6h3v6h5v-10"/>',
  portfolio: '<path d="M12 3a9 9 0 1 0 9 9h-9z"/><path d="M15.5 3.7A9 9 0 0 1 20.3 8.5h-4.8z"/>',
  wallet: '<path d="M4 6.5h15a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6.5a2 2 0 0 1 2-2h12"/><path d="M21 11h-5a2.5 2.5 0 0 0 0 5h5"/><path d="M16 13.5h.01"/>',
  bonuses: '<path d="M3.5 8h17v4h-17zM5 12v9h14v-9M12 8v13"/><path d="M12 8C6 8 6.500 2.500 9.5 3.5 11 4 12 6 12 8c0-2 1-4 2.500-4.5C17.500 2.500 18 8 12 8"/>',
  partners: '<circle cx="9" cy="8" r="3.3"/><circle cx="17.500" cy="9" r="2.5"/><path d="M2.800 20c.4-3.2 2.8-5.300 6.200-5.300s5.800 2.100 6.200 5.300M15.500 15c2.800 0 4.800 1.500 5.500 4"/>',
  vip: '<path d="m3 8 4-4.5h10L21 8l-9 12.500z"/><path d="M3 8h18M8.500 8 12 20.500 15.500 8 13.500 3.500M8.500 8l2-4.5"/>',
  down: '<path d="M12 4v13M6.500 12 12 17.500 17.500 12M5 21h14"/>',
  up: '<path d="M12 17V4M6.500 9 12 3.500 17.500 9M5 21h14"/>',
  invite: '<path d="M15 20v-1.500a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V20"/><circle cx="9" cy="7.500" r="3.5"/><path d="M19 8v6M16 11h6"/>',
  copy: '<rect x="8.500" y="8.500" width="12" height="12" rx="2.5"/><path d="M15.500 8.500V6a2.500 2.500 0 0 0-2.500-2.500H6A2.500 2.500 0 0 0 3.500 6v7A2.500 2.500 0 0 0 6 15.500h2.5"/>',
  share: '<path d="m21 3-7.500 18-3.2-7.300L3 10.500zM21 3 10.300 13.700"/>',
  check: '<path d="m4.500 12.500 5 5 10-11"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.500V12l3 2"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  lock: '<rect x="5" y="10.500" width="14" height="10" rx="2.5"/><path d="M8 10.500V8a4 4 0 0 1 8 0v2.5"/>',
  shield: '<path d="M12 3 4.500 6v5.500c0 4.7 3.100 7.900 7.500 9.500 4.400-1.600 7.500-4.800 7.500-9.5V6z"/><path d="m8.500 12 2.500 2.500 4.500-5"/>',
};

export const icon = (name) => new Safe(
  `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] ?? ''}</svg>`,
);

export const STATUS = {
  done: { label: 'Выполнено', tone: 'ok', icon: 'check' },
  pending: { label: 'В обработке', tone: 'wait', icon: 'clock' },
  declined: { label: 'Отклонено', tone: 'bad', icon: 'close' },
  cancelled: { label: 'Отменено', tone: 'off', icon: 'close' },
};

export const opRow = (op) => html`
  <button class="list-row" data-action="op" data-id="${op.id}">
    <span class="row-icon ${op.type}">${icon(op.type === 'deposit' ? 'down' : 'up')}</span>
    <span class="row-main">
      <b>${op.type === 'deposit' ? 'Пополнение' : 'Вывод'}</b>
      <small>${shortDate(op.ts)}, демо</small>
    </span>
    <span class="row-end">
      <b class="num ${op.status === 'done' && op.type === 'deposit' ? 'pos' : ''} ${op.status === 'declined' || op.status === 'cancelled' ? 'void' : ''}">${signedRub(op)}</b>
      <small class="status ${STATUS[op.status].tone}">${STATUS[op.status].label}</small>
    </span>
  </button>`;

export const segmented = (name, options, active, label) => html`
  <div class="segmented" role="group" aria-label="${label}">
    ${options.map(([value, text]) => html`<button data-action="${name}" data-value="${value}" aria-pressed="${String(value) === String(active)}">${text}</button>`)}
  </div>`;

let toastTimer;
export function toast(message) {
  const element = document.getElementById('toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove('show'), 2600);
}

let sheetState = null;
let returnFocus = null;

export const isSheetOpen = () => sheetState !== null;

function setBackgroundInert(value) {
  document.querySelectorAll('.app, .tabbar').forEach((element) => { element.inert = value; });
}

export function openSheet(title, content, { onChange } = {}) {
  const layer = document.getElementById('sheetLayer');
  if (!sheetState) returnFocus = document.activeElement;
  sheetState = { onChange };
  document.getElementById('sheetTitle').textContent = title;
  mount(document.getElementById('sheetBody'), content);
  layer.hidden = false;
  setBackgroundInert(true);
  document.body.classList.add('locked');
  document.getElementById('sheet').focus({ preventScroll: true });
}

export function closeSheet() {
  if (!sheetState) return;
  sheetState = null;
  document.getElementById('sheetLayer').hidden = true;
  setBackgroundInert(false);
  document.body.classList.remove('locked');
  returnFocus?.focus?.({ preventScroll: true });
}

/** Даёт открытой шторке перерисоваться, когда меняются данные. */
export function refreshSheet() { sheetState?.onChange?.(); }

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.className = 'offscreen';
    document.body.append(area);
    area.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    area.remove();
    return ok;
  }
}
