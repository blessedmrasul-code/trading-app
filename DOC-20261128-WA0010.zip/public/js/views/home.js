import { html, mount, rub, icon, opRow, segmented, shortDate, fullDate, plural } from '../ui.js';
import { areaChart, bindScrub, bars } from '../charts.js';
import { dayKey } from '../state.js';

export const VERIFY_TEXT = {
  checking: ['Проверяем вход', 'wait'],
  verified: ['Вход через Telegram подтверждён', 'ok'],
  outside: ['Открыто вне Telegram', 'off'],
  invalid: ['Подпись Telegram не прошла проверку', 'bad'],
  unconfigured: ['Серверная проверка не настроена', 'off'],
  unavailable: ['Сервер проверки недоступен', 'off'],
};

function greeting(hour) {
  if (hour < 5) return 'Доброй ночи';
  if (hour < 12) return 'Доброе утро';
  if (hour < 18) return 'Добрый день';
  return 'Добрый вечер';
}

function weekActivity(activity) {
  const weekday = new Intl.DateTimeFormat('ru-RU', { weekday: 'short' });
  return Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const key = dayKey(date.getTime());
    return { label: weekday.format(date), today: i === 6, value: activity.filter((a) => dayKey(a.ts) === key).length };
  });
}

export function renderHome(root, ctx) {
  const { store, user, ui } = ctx;
  const totals = store.totals();
  const level = store.level();
  const days = ui.homePeriod;
  const history = store.history(days);
  const change = totals.balance - history[0].value;
  const caption = `${change >= 0 ? '+' : '−'}${rub(Math.abs(change))} за ${days} ${plural(days, 'день', 'дня', 'дней')}`;
  const [verifyLabel, verifyTone] = VERIFY_TEXT[ctx.verify];
  const week = weekActivity(store.state.activity);
  const recent = store.state.activity.slice(-3).reverse();
  const checkin = store.checkinStatus();

  mount(root, html`
    <div class="greeting">
      <h1>${greeting(new Date().getHours())}${user?.firstName ? html`,<br>${user.firstName}` : ''}</h1>
      <p>Твой кабинет NEXORA</p>
    </div>

    <article class="hero">
      <div class="hero-top">
        <p class="hero-label" id="heroLabel">Демо-баланс</p>
        <p class="hero-amount num" id="heroAmount">${rub(totals.balance)}</p>
        <p class="hero-caption num" id="heroCaption">${caption}</p>
      </div>
      ${areaChart(history.map((p) => p.value), { id: 'home', height: 108, label: `Изменение демо-баланса за ${days} дней` })}
      ${segmented('home-period', [[7, '7 дней'], [30, '30 дней'], [90, '90 дней']], days, 'Период графика')}
      <div class="hero-actions">
        <button class="btn primary" data-action="deposit">${icon('down')}Пополнить</button>
        <button class="btn" data-action="withdraw">${icon('up')}Вывести</button>
        <button class="btn square" data-go="partners" aria-label="Пригласить друга">${icon('invite')}</button>
      </div>
    </article>

    <h2>Статус аккаунта</h2>
    <article class="card status-card">
      <div class="status-head">
        <div class="level-orb" style="--p:${Math.round(level.progress * 100)}"><span>${level.index + 1}</span></div>
        <div>
          <b>Уровень «${level.current.name}»</b>
          <p class="muted">${level.next ? `Ещё ${level.next.from - store.state.points} очков до уровня «${level.next.name}»` : 'Максимальный уровень'}</p>
        </div>
      </div>
      <dl class="facts">
        <div><dt>Тариф</dt><dd>Базовый</dd></div>
        <div><dt>Режим</dt><dd>Демонстрационный</dd></div>
        <div><dt>Telegram</dt><dd class="status ${verifyTone}">${verifyLabel}</dd></div>
      </dl>
    </article>

    <div class="stats">
      <button class="stat" data-go="wallet"><small>Пополнено</small><b class="num pos">${rub(totals.deposited)}</b></button>
      <button class="stat" data-go="wallet"><small>Выведено</small><b class="num">${rub(totals.withdrawn)}</b></button>
      <button class="stat" data-go="bonuses"><small>Бонусные очки</small><b class="num accent">${store.state.points}</b></button>
      <button class="stat" data-go="bonuses"><small>Серия отметок</small><b class="num">${checkin.streak} ${plural(checkin.streak, 'день', 'дня', 'дней')}</b></button>
    </div>

    ${!checkin.claimedToday && html`
      <button class="nudge" data-go="bonuses">
        <span class="row-icon gift">${icon('bonuses')}</span>
        <span class="row-main"><b>Ежедневная отметка ждёт</b><small>Забери ${checkin.reward} очков</small></span>
        <span class="chevron" aria-hidden="true">›</span>
      </button>`}

    <h2>Активность за неделю</h2>
    <article class="card">
      ${bars(week)}
      <ul class="timeline">
        ${recent.map((a) => html`<li><span>${a.text}</span><time title="${fullDate(a.ts)}">${shortDate(a.ts)}</time></li>`)}
      </ul>
    </article>

    <div class="section-head"><h2>Последние операции</h2><button class="link" data-go="wallet">Все операции</button></div>
    <div class="card list">${store.state.ops.slice(0, 3).map(opRow)}</div>
  `);

  const amount = root.querySelector('#heroAmount');
  const label = root.querySelector('#heroLabel');
  bindScrub(root, history.map((p) => p.value), (index) => {
    amount.textContent = rub(index === null ? totals.balance : history[index].value);
    label.textContent = index === null ? 'Демо-баланс' : `Демо-баланс на ${shortDate(history[index].ts)}`;
  });
}
