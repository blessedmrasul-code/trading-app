import { html, mount, icon, segmented, openSheet } from '../ui.js';

export const PLANS = {
  30: { name: '30 дней', title: 'Знакомство', perks: ['Фиолетовое оформление профиля', 'Расширенная аналитика портфеля', 'VIP-значок'] },
  90: { name: '90 дней', title: 'Сезон', perks: ['Всё из тарифа на 30 дней', 'Дополнительные задания', 'Отчёты по операциям'] },
  365: { name: '365 дней', title: 'Год', perks: ['Всё из тарифа на 90 дней', 'Ранний доступ к новым функциям', 'Приоритетная поддержка'] },
};

const COMPARE = [
  ['Кабинет, портфель и кошелёк', true, true, true, true],
  ['Ежедневные бонусы', true, true, true, true],
  ['VIP-оформление и значок', false, true, true, true],
  ['Расширенная аналитика', false, true, true, true],
  ['Дополнительные задания', false, false, true, true],
  ['Отчёты по операциям', false, false, true, true],
  ['Ранний доступ', false, false, false, true],
  ['Приоритетная поддержка', false, false, false, true],
];

const COLUMN = { 30: 2, 90: 3, 365: 4 };

export function openVipSoon(days) {
  openSheet(`VIP на ${PLANS[days].name}`, html`
    <p>Оформить тариф пока нельзя: оплата не подключена и цена не назначена.</p>
    <p class="note">Ничего не списано. VIP не обещает дохода: это набор функций и оформление.</p>
    <button class="btn primary wide" data-action="close-sheet">Понятно</button>
  `);
}

export function renderVip(root, ctx) {
  const days = ctx.ui.vipPlan;
  const plan = PLANS[days];
  const column = COLUMN[days];
  const mark = (value) => (value
    ? html`<span class="yes">${icon('check')}<span class="sr">есть</span></span>`
    : html`<span class="no">–<span class="sr">нет</span></span>`);

  mount(root, html`
    <div class="page-head"><h1>NEXORA VIP</h1><p>Концепция тарифов, продажи не открыты</p></div>

    <div class="vip-stage">
      <article class="vip-card" id="vipCard">
        <div class="vip-card-top"><span>NEXORA</span>${icon('vip')}</div>
        <p class="vip-word">VIP</p>
        <div class="vip-card-bottom"><span>${ctx.user?.firstName || 'Твоё имя'}</span><span>${plan.name}</span></div>
      </article>
    </div>

    ${segmented('vip-plan', Object.entries(PLANS).map(([k, p]) => [k, p.name]), days, 'Срок тарифа')}

    <article class="card plan">
      <div class="section-head"><h3>Тариф «${plan.title}»</h3><span class="tag violet">Скоро</span></div>
      <p class="plan-price">Цена пока не назначена</p>
      <ul class="perks">${plan.perks.map((p) => html`<li>${icon('check')}<span>${p}</span></li>`)}</ul>
      <button class="btn vip wide" data-action="vip-buy">Выбрать ${plan.name}</button>
    </article>

    <h2>Сравнение</h2>
    <div class="card table-wrap">
      <table>
        <thead><tr>
          <th scope="col">Возможность</th>
          <th scope="col">Базовый</th>
          ${[30, 90, 365].map((d, i) => html`<th scope="col" class="${column === i + 2 ? 'on' : ''}">${d}<small>дней</small></th>`)}
        </tr></thead>
        <tbody>
          ${COMPARE.map(([name, ...cells]) => html`<tr><th scope="row">${name}</th>
            ${cells.map((v, i) => html`<td class="${i + 1 === column ? 'on' : ''}">${mark(v)}</td>`)}</tr>`)}
        </tbody>
      </table>
    </div>
    <p class="note">Состав тарифов может измениться до запуска. VIP не связан с доходностью.</p>
  `);

  // Лёгкий наклон карты за пальцем.
  const card = root.querySelector('#vipCard');
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  card.addEventListener('pointermove', (e) => {
    const box = card.getBoundingClientRect();
    const x = (e.clientX - box.left) / box.width - 0.5;
    const y = (e.clientY - box.top) / box.height - 0.5;
    card.style.setProperty('--rx', `${(-y * 12).toFixed(2)}deg`);
    card.style.setProperty('--ry', `${(x * 14).toFixed(2)}deg`);
    card.style.setProperty('--gx', `${((x + 0.5) * 100).toFixed(0)}%`);
  });
  const reset = () => ['--rx', '--ry', '--gx'].forEach((p) => card.style.removeProperty(p));
  card.addEventListener('pointerleave', reset);
  card.addEventListener('pointerup', reset);
  card.addEventListener('pointercancel', reset);
}
