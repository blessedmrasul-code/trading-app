import { html, mount, icon, plural } from '../ui.js';
import { CHECKIN_REWARDS, TASKS, LEVELS } from '../state.js';

export function renderBonuses(root, ctx) {
  const { store } = ctx;
  const checkin = store.checkinStatus();
  const level = store.level();
  const { done, claimed, points } = store.state;
  const completed = TASKS.filter((t) => done[t.id]).length;
  const filled = checkin.claimedToday ? checkin.index + 1 : checkin.index;

  mount(root, html`
    <div class="page-head"><h1>Бонусы</h1><p>Очки не являются деньгами и не обмениваются на них</p></div>

    <article class="points-card">
      <p class="hero-label">Твои очки</p>
      <p class="hero-amount num">${points}</p>
      <div class="progress" role="progressbar" aria-valuenow="${Math.round(level.progress * 100)}" aria-valuemin="0" aria-valuemax="100" aria-label="Прогресс уровня">
        <i style="width:${level.progress * 100}%"></i>
      </div>
      <p class="hero-caption">${level.next ? `«${level.current.name}», до «${level.next.name}» ${level.next.from - points}` : `«${level.current.name}», максимальный уровень`}</p>
    </article>

    <h2>Ежедневная отметка</h2>
    <article class="card">
      <ol class="streak">
        ${CHECKIN_REWARDS.map((reward, i) => html`
          <li class="${i < filled ? 'got' : ''} ${i === checkin.index && !checkin.claimedToday ? 'next' : ''}">
            <span>${i < filled ? icon('check') : `+${reward}`}</span><small>День ${i + 1}</small>
          </li>`)}
      </ol>
      <button class="btn primary wide" data-action="checkin" ${checkin.claimedToday ? 'disabled' : ''}>
        ${checkin.claimedToday ? 'Сегодня уже отмечено' : `Забрать ${checkin.reward} очков`}
      </button>
      <p class="note">Серия: ${checkin.streak} ${plural(checkin.streak, 'день', 'дня', 'дней')}. Пропущенный день начинает её заново.</p>
    </article>

    <div class="section-head"><h2>Задания на сегодня</h2><span class="muted num">${completed} из ${TASKS.length}</span></div>
    <div class="card list">
      ${TASKS.map((t) => html`
        <div class="list-row task">
          <span class="row-icon ${done[t.id] ? 'deposit' : ''}">${icon(done[t.id] ? 'check' : 'bonuses')}</span>
          <span class="row-main">
            <b>${t.title}</b>
            <small class="num">+${t.points} очков, ${done[t.id] ? 1 : 0} из ${t.goal}</small>
            <span class="progress thin"><i style="width:${done[t.id] ? 100 : 0}%"></i></span>
          </span>
          ${claimed[t.id]
            ? html`<span class="status ok">Получено</span>`
            : done[t.id]
              ? html`<button class="btn small primary" data-action="claim" data-id="${t.id}">Забрать</button>`
              : html`<button class="btn small" data-go="${t.go}">Перейти</button>`}
        </div>`)}
    </div>

    <h2>Награды за уровни</h2>
    <ol class="ladder">
      ${LEVELS.map((l, i) => html`
        <li class="${i <= level.index ? 'open' : ''} ${i === level.index ? 'current' : ''}">
          <span class="ladder-node">${i <= level.index ? icon('check') : icon('lock')}</span>
          <span class="row-main"><b>${l.name}</b><small>${l.reward}</small></span>
          <span class="muted num">${l.from}</span>
        </li>`)}
    </ol>
    <p class="note">Награды уровней показаны как концепция и пока не выдаются.</p>
  `);
}
