import { html, mount, rub, signedRub, fullDate, icon, opRow, segmented, openSheet, closeSheet, toast, STATUS } from '../ui.js';
import { MIN_AMOUNT } from '../state.js';
import { haptic } from '../telegram.js';

const METHODS = {
  deposit: [['Демо-счёт', 'Мгновенная имитация', true], ['Telegram Stars', 'Не подключено', false], ['Банковская карта', 'Не подключено', false]],
  withdraw: [['Демо-реквизиты', 'Имитация заявки', true], ['Банковская карта', 'Не подключено', false]],
};

export function openOperationForm(type, ctx) {
  const deposit = type === 'deposit';
  const { available } = ctx.store.totals();
  openSheet(deposit ? 'Пополнение (демо)' : 'Вывод (демо)', html`
    <p class="banner">Деньги не списываются и не переводятся. Это имитация на устройстве.</p>
    <form id="opForm" novalidate>
      <label for="amount">Сумма, ₽</label>
      <input id="amount" name="amount" inputmode="decimal" autocomplete="off" placeholder="От ${MIN_AMOUNT}" maxlength="12" aria-describedby="amountHint">
      <p class="hint" id="amountHint">${deposit ? `Минимум ${MIN_AMOUNT} ₽` : `Доступно ${rub(available)}`}</p>
      <div class="chips">
        ${[100, 500, 1000, 5000].map((v) => html`<button type="button" data-amount="${v}">${rub(v)}</button>`)}
        ${!deposit && html`<button type="button" data-amount="${available}">Всё</button>`}
      </div>
      <fieldset>
        <legend>Способ</legend>
        ${METHODS[type].map(([name, hint, enabled], i) => html`
          <label class="method ${enabled ? '' : 'disabled'}">
            <input type="radio" name="method" value="${name}" ${i === 0 ? 'checked' : ''} ${enabled ? '' : 'disabled'}>
            <span class="row-main"><b>${name}</b><small>${hint}</small></span>
          </label>`)}
      </fieldset>
      <button class="btn primary wide" type="submit">${deposit ? 'Создать демо-пополнение' : 'Создать демо-вывод'}</button>
    </form>
  `);

  const form = document.getElementById('opForm');
  const input = form.querySelector('#amount');
  const hint = form.querySelector('#amountHint');
  const initialHint = hint.textContent;
  const setError = (message) => {
    hint.textContent = message || initialHint;
    hint.classList.toggle('error', Boolean(message));
    input.setAttribute('aria-invalid', String(Boolean(message)));
  };
  input.addEventListener('input', () => setError(''));
  form.querySelectorAll('[data-amount]').forEach((chip) => chip.addEventListener('click', () => {
    input.value = chip.dataset.amount;
    setError('');
    haptic('select');
  }));
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const result = ctx.store.createOp(type, input.value, new FormData(form).get('method'));
    if (result.error) {
      setError(result.error);
      haptic('error');
      return;
    }
    closeSheet();
    ctx.go('wallet');
    toast('Демо-заявка создана, статус обновится через несколько секунд');
    haptic('success');
  });
}

export function openOperation(id, ctx) {
  const draw = () => {
    const op = ctx.store.state.ops.find((o) => o.id === id);
    if (!op) return closeSheet();
    const status = STATUS[op.status];
    openSheet(op.type === 'deposit' ? 'Пополнение (демо)' : 'Вывод (демо)', html`
      <div class="op-hero">
        <span class="op-mark ${status.tone}">${icon(status.icon)}</span>
        <b class="num">${signedRub(op)}</b>
        <span class="status ${status.tone}">${status.label}</span>
      </div>
      <dl class="facts">
        <div><dt>Создана</dt><dd>${fullDate(op.ts)}</dd></div>
        <div><dt>Способ</dt><dd>${op.method}</dd></div>
        <div><dt>Номер</dt><dd class="mono">${op.id}</dd></div>
      </dl>
      <p class="note">Демонстрационная запись. Реальных денег за ней нет.</p>
      ${op.status === 'pending' && html`<button class="btn wide" data-action="cancel-op" data-id="${op.id}">Отменить заявку</button>`}
    `, { onChange: draw });
  };
  draw();
}

export function renderWallet(root, ctx) {
  const { store, ui } = ctx;
  const totals = store.totals();
  const filtered = store.state.ops.filter((o) => ui.walletFilter === 'all'
    || (ui.walletFilter === 'pending' ? o.status === 'pending' : o.type === ui.walletFilter));

  mount(root, html`
    <div class="page-head"><h1>Кошелёк</h1><p>Платёжные системы не подключены</p></div>

    <article class="wallet-card">
      <div class="wallet-card-top"><span>NEXORA</span><span class="tag">Демо</span></div>
      <p class="hero-label">Доступно</p>
      <p class="hero-amount num">${rub(totals.available)}</p>
      <p class="hero-caption num">${totals.reserved ? `${rub(totals.reserved)} в заявках на вывод` : 'Нет заявок на вывод'}</p>
    </article>

    <div class="duo">
      <button class="btn primary" data-action="deposit">${icon('down')}Пополнить</button>
      <button class="btn" data-action="withdraw">${icon('up')}Вывести</button>
    </div>

    <div class="stats">
      <div class="stat"><small>Всего пополнено</small><b class="num pos">${rub(totals.deposited)}</b></div>
      <div class="stat"><small>Всего выведено</small><b class="num">${rub(totals.withdrawn)}</b></div>
    </div>

    <h2>История операций</h2>
    ${segmented('wallet-filter', [['all', 'Все'], ['deposit', 'Пополнения'], ['withdraw', 'Выводы'], ['pending', 'В работе']], ui.walletFilter, 'Фильтр операций')}
    <div class="card list">
      ${filtered.length ? filtered.map(opRow) : html`<p class="empty">Таких операций пока нет. Создай демо-пополнение, и оно появится здесь.</p>`}
    </div>
  `);
}
