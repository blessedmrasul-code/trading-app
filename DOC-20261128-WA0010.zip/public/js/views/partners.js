import { html, mount, rub, icon } from '../ui.js';
import { REF_GOAL, REF_REWARD } from '../state.js';

export const BOT_USERNAME = 'NexoraMintBot';

export function referralLink(user) {
  return `https://t.me/${BOT_USERNAME}?startapp=ref_${user ? user.id : 'demo'}`;
}

// 25 узлов сети: каждый приглашённый «зажигает» один.
function network(invited) {
  const nodes = Array.from({ length: REF_GOAL }, (_, i) => {
    const ring = i < 8 ? 0 : 1;
    const count = ring ? REF_GOAL - 8 : 8;
    const angle = ((ring ? i - 8 : i) / count) * Math.PI * 2 - Math.PI / 2;
    const radius = ring ? 88 : 48;
    return [100 + Math.cos(angle) * radius, 100 + Math.sin(angle) * radius];
  });
  return html`
    <svg class="network" viewBox="0 0 200 200" role="img" aria-label="Приглашено ${invited} из ${REF_GOAL}">
      ${nodes.map(([x, y]) => html`<line x1="100" y1="100" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}"/>`)}
      ${nodes.map(([x, y], i) => html`<circle class="${i < invited ? 'lit' : ''}" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5"/>`)}
      <circle class="core" cx="100" cy="100" r="25"/>
      <text x="100" y="101">${invited}/${REF_GOAL}</text>
    </svg>`;
}

export function renderPartners(root, ctx) {
  const invited = 0; // Учёт приглашений требует сервера и базы данных.
  const link = referralLink(ctx.user);
  const invitedBy = ctx.startParam.startsWith('ref_') && ctx.startParam !== `ref_${ctx.user?.id}`;

  mount(root, html`
    <div class="page-head"><h1>Партнёры</h1><p>Приглашай друзей в NEXORA</p></div>

    ${invitedBy && html`<p class="banner">Ты открыл приложение по приглашению. Учёт приглашений пока не подключён.</p>`}

    <article class="card center">
      ${network(invited)}
      <p><b>Цель: ${REF_GOAL} приглашённых</b></p>
      <p class="muted">Планируемая награда за цель ${rub(REF_REWARD)}. Сейчас она не начисляется: программа не запущена.</p>
    </article>

    <h2>Твоя ссылка</h2>
    <article class="card">
      <button class="linkbox" data-action="copy-link" aria-label="Скопировать ссылку">
        <span>${link.replace('https://', '')}</span>${icon('copy')}
      </button>
      <div class="duo">
        <button class="btn primary" data-action="copy-link">${icon('copy')}Скопировать</button>
        <button class="btn" data-action="share-link">${icon('share')}Отправить</button>
      </div>
      ${!ctx.user && html`<p class="note">Это пример. Личная ссылка появится, когда приложение открыто в Telegram.</p>`}
    </article>

    <div class="stats three">
      <div class="stat"><small>Приглашено</small><b class="num accent">${invited}</b></div>
      <div class="stat"><small>Активных</small><b class="num">0</b></div>
      <div class="stat"><small>Бонусы</small><b class="num">${rub(0)}</b></div>
    </div>

    <h2>Как это будет работать</h2>
    <ol class="steps">
      <li><b>Отправь ссылку</b><span>Скопируй её или сразу выбери чат в Telegram.</span></li>
      <li><b>Друг открывает NEXORA</b><span>Ссылка запускает приложение и передаёт код приглашения.</span></li>
      <li><b>Сервер засчитывает приглашение</b><span>Этот шаг ещё не подключён, поэтому счётчик остаётся нулевым.</span></li>
    </ol>

    <h2>Мои приглашённые</h2>
    <div class="card"><p class="empty">Здесь появятся друзья, когда заработает учёт приглашений.</p></div>
  `);
}
