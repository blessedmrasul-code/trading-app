import { html, mount, rub, percent, segmented, shortDate, signedRub, openSheet } from '../ui.js';
import { areaChart, bindScrub, donut, sparkline, demoSeries } from '../charts.js';
import { ASSETS } from '../state.js';

// Суммы распределяются так, чтобы части всегда давали ровно весь баланс.
export function allocate(balance) {
  const cents = Math.round(balance * 100);
  let left = cents;
  return ASSETS.map((asset, i) => {
    const part = i === ASSETS.length - 1 ? left : Math.floor((cents * asset.share) / 100);
    left -= part;
    return { ...asset, value: part / 100 };
  });
}

const series = (asset, days) => demoSeries(asset.id, days, asset.volatility, asset.drift);
const change = (values) => (values.at(-1) / values[0] - 1) * 100;
const tone = (n) => (n > 0.05 ? 'pos' : n < -0.05 ? 'neg' : 'flat');

export function openAsset(id, ctx) {
  const asset = allocate(ctx.store.totals().balance).find((a) => a.id === id);
  if (!asset) return;
  const values = series(asset, 90);
  openSheet(asset.name, html`
    <p class="muted">${asset.kind}. Вымышленный актив для демонстрации интерфейса.</p>
    <dl class="facts">
      <div><dt>В портфеле</dt><dd class="num">${rub(asset.value)}</dd></div>
      <div><dt>Доля</dt><dd class="num">${asset.share}%</dd></div>
      <div><dt>Учебный курс за 90 дней</dt><dd class="num ${tone(change(values))}">${percent(change(values))}</dd></div>
    </dl>
    ${areaChart(values, { id: 'asset', height: 120, label: `Учебный курс: ${asset.name}` })}
    <p class="note">Курс сгенерирован программой, не является рыночными данными и не влияет на демо-баланс.</p>
  `);
}

export function renderPortfolio(root, ctx) {
  const { store, ui } = ctx;
  const { balance } = store.totals();
  const assets = allocate(balance);
  const days = ui.portfolioPeriod;
  const history = store.history(days);
  const values = history.map((p) => p.value);
  const selected = assets.find((a) => a.id === ui.segment);
  const done = store.state.ops.filter((o) => o.status === 'done');
  const average = values.reduce((a, b) => a + b, 0) / values.length;

  mount(root, html`
    <div class="page-head"><h1>Портфель</h1><p>Учебные активы на демо-балансе</p></div>

    <article class="card allocation">
      ${donut(assets, ui.segment, html`
        <small>${selected ? selected.name : 'Всего'}</small>
        <b class="num">${rub(selected ? selected.value : balance)}</b>`)}
      <ul class="legend">
        ${assets.map((a) => html`
          <li><button data-action="segment" data-value="${a.id}" aria-pressed="${ui.segment === a.id}">
            <i style="background:${a.color}"></i><span>${a.name}</span><b class="num">${a.share}%</b>
          </button></li>`)}
      </ul>
    </article>

    <h2>Динамика</h2>
    <article class="card">
      <p class="chart-readout"><b class="num" id="pfValue">${rub(balance)}</b><span id="pfDate">сегодня</span></p>
      ${areaChart(values, { id: 'portfolio', height: 140, label: `Стоимость демо-портфеля за ${days} дней` })}
      ${segmented('portfolio-period', [[30, '30 дней'], [90, '90 дней'], [365, '365 дней']], days, 'Период графика')}
      <p class="note">График строится по демо-пополнениям и выводам. Доходность не моделируется.</p>
    </article>

    <h2>Статистика</h2>
    <div class="stats">
      <div class="stat"><small>Максимум за период</small><b class="num">${rub(Math.max(...values))}</b></div>
      <div class="stat"><small>В среднем за период</small><b class="num">${rub(Math.round(average))}</b></div>
      <div class="stat"><small>Активов</small><b class="num">${assets.length}</b></div>
      <div class="stat"><small>Выполнено операций</small><b class="num">${done.length}</b></div>
    </div>

    <div class="section-head"><h2>Активы</h2><span class="muted">курс за ${days === 30 ? 30 : 90} дней</span></div>
    <div class="card list">
      ${assets.map((a) => {
        const s = series(a, Math.min(days, 90));
        const c = change(s);
        return html`
          <button class="list-row asset" data-action="asset" data-id="${a.id}">
            <i class="asset-dot" style="background:${a.color}"></i>
            <span class="row-main"><b>${a.name}</b><small>${a.kind}</small></span>
            ${sparkline(s, tone(c))}
            <span class="row-end"><b class="num">${rub(a.value)}</b><small class="num ${tone(c)}">${percent(c)}</small></span>
          </button>`;
      })}
    </div>

    <h2>История портфеля</h2>
    <div class="card">
      <ul class="timeline solo">
        ${done.slice(0, 6).map((o) => html`
          <li><span>${o.type === 'deposit' ? 'Распределено по активам' : 'Выведено из активов'} <b class="num">${signedRub(o)}</b></span><time>${shortDate(o.ts)}</time></li>`)}
      </ul>
    </div>
  `);

  const readout = root.querySelector('#pfValue');
  const date = root.querySelector('#pfDate');
  bindScrub(root, values, (index) => {
    readout.textContent = rub(index === null ? balance : values[index]);
    date.textContent = index === null ? 'сегодня' : shortDate(history[index].ts);
  });
}
