// Обёртка над официальным Telegram WebApp API.
// Всё, что берётся из initDataUnsafe, используется только для отображения:
// это не аутентификация. Подлинность проверяет сервер по строке initData.

const tg = window.Telegram?.WebApp;

export const inTelegram = Boolean(tg?.initData);

const supports = (version) => Boolean(tg?.isVersionAtLeast?.(version));

const clip = (value, max) => (typeof value === 'string' ? value.slice(0, max) : '');

export function getUser() {
  const user = tg?.initDataUnsafe?.user;
  if (!user || !Number.isSafeInteger(user.id)) return null;
  return {
    id: user.id,
    firstName: clip(user.first_name, 64),
    lastName: clip(user.last_name, 64),
    username: clip(user.username, 32),
    isPremium: user.is_premium === true,
  };
}

export function getStartParam() {
  const param = tg?.initDataUnsafe?.start_param;
  return typeof param === 'string' && /^[A-Za-z0-9_-]{1,512}$/.test(param) ? param : '';
}

// 'brand' — фирменная тёмная тема; 'telegram' — следует за темой клиента.
let themeMode = 'brand';

export function applyTheme(mode = themeMode) {
  themeMode = mode;
  const scheme = mode === 'telegram'
    ? (inTelegram ? tg.colorScheme : (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'))
    : 'dark';
  const theme = scheme === 'light' ? 'light' : 'dark';
  document.documentElement.dataset.theme = theme;

  const color = theme === 'light' ? '#f2f5fc' : '#04070f';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', color);
  if (!inTelegram) return;
  if (supports('6.1')) tg.setBackgroundColor(color);
  if (supports('6.9')) tg.setHeaderColor(color);
  if (supports('7.10')) tg.setBottomBarColor(color);
}

export function initTelegram() {
  if (!tg) return;
  tg.ready();
  tg.expand();
  // Свайп вниз по умолчанию сворачивает приложение и мешает прокрутке.
  if (inTelegram && supports('7.7')) tg.disableVerticalSwipes();
  tg.onEvent('themeChanged', () => applyTheme());
}

export function setBackButton(visible) {
  if (!inTelegram || !supports('6.1')) return;
  if (visible) tg.BackButton.show();
  else tg.BackButton.hide();
}

export function onBack(handler) {
  if (inTelegram && supports('6.1')) tg.BackButton.onClick(handler);
}

export function haptic(kind = 'light') {
  if (!inTelegram || !supports('6.1')) return;
  const feedback = tg.HapticFeedback;
  if (kind === 'success' || kind === 'error' || kind === 'warning') feedback.notificationOccurred(kind);
  else if (kind === 'select') feedback.selectionChanged();
  else feedback.impactOccurred(kind);
}

export function shareLink(url, text) {
  const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
  if (inTelegram && supports('6.1')) tg.openTelegramLink(shareUrl);
  else window.open(shareUrl, '_blank', 'noopener');
}

/**
 * Отправляет initData на сервер для проверки подписи.
 * Возвращает один из статусов: outside | verified | invalid | unconfigured | unavailable
 */
export async function verifySession() {
  if (!inTelegram) return 'outside';
  try {
    const response = await fetch('/api/verify', {
      method: 'POST',
      headers: { Authorization: `tma ${tg.initData}` },
      signal: AbortSignal.timeout?.(8000),
    });
    const type = response.headers.get('content-type') || '';
    if (!type.includes('application/json')) return 'unavailable';
    const body = await response.json();
    if (response.ok && body.ok === true) return 'verified';
    if (response.status === 401) return 'invalid';
    if (response.status === 503) return 'unconfigured';
    return 'unavailable';
  } catch {
    return 'unavailable';
  }
}
