// Лёгкие SVG-графики без внешних библиотек.
import { html } from './ui.js';

const W = 320;

function points(values, height, pad = 6) {
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  return values.map((v, i) => [
    (i / Math.max(values.length - 1, 1)) * W,
    max === min ? height / 2 : pad + (1 - (v - min) / span) * (height - pad * 2),
  ]);
}

const path = (pts) => pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join('');

export function areaChart(values, { id, height = 110, label }) {
  const pts = points(values, height, 10);
  const line = path(pts);
  return html`
    <div class="chart" data-scrub="${id}" style="height:${height}px">
      <svg viewBox="0 0 ${W} ${height}" preserveAspectRatio="none" role="img" aria-label="${label}">
        <defs>
          <linearGradient id="${id}-line" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0" class="stop-teal"/><stop offset=".55" class="stop-blue"/><stop offset="1" class="stop-violet"/>
          </linearGradient>
          <linearGradient id="${id}-fill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" class="stop-blue" stop-opacity=".38"/><stop offset="1" class="stop-blue" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <path d="${line}L${W} ${height}L0 ${height}Z" fill="url(#${id}-fill)"/>
        <path class="chart-line" d="${line}" stroke="url(#${id}-line)" pathLength="1"/>
      </svg>
      <span class="chart-cursor" hidden></span>
      <span class="chart-dot" style="left:100%;top:${(pts.at(-1)[1] / height) * 100}%"></span>
    </div>`;
}

/** Ведение пальцем по графику: вызывает onPoint(индекс) или onPoint(null). */
export function bindScrub(root, series, onPoint) {
  const chart = root.querySelector('[data-scrub]');
  if (!chart) return;
  const cursor = chart.querySelector('.chart-cursor');
  const dot = chart.querySelector('.chart-dot');
  const height = chart.querySelector('svg').viewBox.baseVal.height;
  const pts = points(series, height, 10);

  const show = (index) => {
    const [x, y] = pts[index];
    dot.style.left = `${(x / W) * 100}%`;
    dot.style.top = `${(y / height) * 100}%`;
    cursor.style.left = `${(x / W) * 100}%`;
  };
  const move = (event) => {
    const box = chart.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (event.clientX - box.left) / box.width));
    const index = Math.round(ratio * (series.length - 1));
    cursor.hidden = false;
    show(index);
    onPoint(index);
  };
  const end = () => {
    cursor.hidden = true;
    show(series.length - 1);
    onPoint(null);
  };
  chart.addEventListener('pointerdown', move);
  chart.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' || e.buttons) move(e); });
  chart.addEventListener('pointerup', end);
  chart.addEventListener('pointercancel', end);
  chart.addEventListener('pointerleave', end);
}

export function sparkline(values, tone) {
  return html`<svg class="spark ${tone}" viewBox="0 0 ${W} 80" preserveAspectRatio="none" aria-hidden="true"><path d="${path(points(values, 80))}"/></svg>`;
}

export function donut(segments, active, center) {
  const radius = 42;
  const length = 2 * Math.PI * radius;
  let offset = 0;
  return html`
    <div class="donut">
      <svg viewBox="0 0 100 100" role="img" aria-label="Распределение: ${segments.map((s) => `${s.name} ${s.share}%`).join(', ')}">
        ${segments.map((s) => {
          const size = (s.share / 100) * length;
          const circle = html`<circle data-action="segment" data-value="${s.id}" cx="50" cy="50" r="${radius}"
            class="${active && active !== s.id ? 'dim' : ''} ${active === s.id ? 'on' : ''}" style="stroke:${s.color}"
            stroke-dasharray="${Math.max(size - 1.6, 0)} ${length}" stroke-dashoffset="${-offset}"/>`;
          offset += size;
          return circle;
        })}
      </svg>
      <div class="donut-center">${center}</div>
    </div>`;
}

export function bars(items) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return html`
    <ol class="bars">
      ${items.map((i) => html`
        <li class="${i.today ? 'today' : ''}" aria-label="${i.label}: ${i.value}">
          <span class="bar-value">${i.value || ''}</span>
          <span class="bar"><i style="height:${i.value ? Math.max(12, (i.value / max) * 100) : 4}%"></i></span>
          <span class="bar-label">${i.label}</span>
        </li>`)}
    </ol>`;
}

/** Детерминированный учебный ряд цен: одинаковый при каждом запуске. */
export function demoSeries(seedText, days, volatility, drift) {
  let seed = [...seedText].reduce((acc, c) => (acc * 31 + c.charCodeAt(0)) >>> 0, 7);
  const random = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  let value = 100;
  const all = Array.from({ length: 91 }, () => {
    value = Math.max(20, value + (random() - 0.5) * volatility * 2 + drift);
    return value;
  });
  return all.slice(-(days + 1));
}
