// Демонстрационное состояние. Хранится только в браузере пользователя.
// Это НЕ учётная система: для реальных денег всё это должно жить на сервере.

export const MIN_AMOUNT = 100;
export const MAX_AMOUNT = 1_000_000;
export const PENDING_MS = 6000;
export const REF_GOAL = 25;
export const REF_REWARD = 200;

const DAY = 86_400_000;

export const CHECKIN_REWARDS = [10, 15, 20, 25, 30, 40, 60];

export const TASKS = [
  { id: 'portfolio', title: 'Заглянуть в портфель', goal: 1, points: 20, go: 'portfolio' },
  { id: 'invite', title: 'Скопировать ссылку приглашения', goal: 1, points: 30, go: 'partners' },
  { id: 'deposit', title: 'Сделать демо-пополнение', goal: 1, points: 50, go: 'wallet' },
  { id: 'vip', title: 'Сравнить возможности VIP', goal: 1, points: 20, go: 'vip' },
];

export const LEVELS = [
  { name: 'Старт', from: 0, reward: 'Базовый профиль' },
  { name: 'Участник', from: 300, reward: 'Значок участника' },
  { name: 'Профи', from: 1000, reward: 'Особая рамка профиля' },
  { name: 'Элита', from: 3000, reward: 'Фиолетовая карта баланса' },
];

export const ASSETS = [
  { id: 'reserve', name: 'Резерв в рублях', kind: 'Денежная часть', share: 40, color: 'var(--teal)', volatility: 0, drift: 0 },
  { id: 'orion', name: 'Индекс «Орион»', kind: 'Учебный индекс', share: 30, color: 'var(--blue)', volatility: 1.4, drift: 0.09 },
  { id: 'vega', name: 'Корзина «Вега»', kind: 'Учебная корзина', share: 18, color: 'var(--violet)', volatility: 2.1, drift: -0.07 },
  { id: 'lyra', name: 'Фонд «Лира»', kind: 'Учебный фонд', share: 12, color: 'var(--pink)', volatility: 1, drift: 0.03 },
];

export function dayKey(ts = Date.now()) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function seed(now) {
  const op = (n, daysAgo, type, amount, status = 'done') => ({
    id: `seed-${n}`, type, amount, status, ts: now - daysAgo * DAY - n * 3_600_000,
    method: type === 'deposit' ? 'Демо-счёт' : 'Демо-реквизиты',
  });
  const ops = [
    op(1, 82, 'deposit', 5000),
    op(2, 61, 'deposit', 4000),
    op(3, 47, 'withdraw', 1500),
    op(4, 26, 'deposit', 3000),
    op(5, 19, 'withdraw', 2000, 'declined'),
    op(6, 5, 'deposit', 2500),
    op(7, 2, 'withdraw', 500),
  ].reverse();
  return {
    version: 1,
    ops,
    points: 120,
    streak: 0,
    lastCheckin: '',
    tasksDay: dayKey(now),
    done: {},
    claimed: {},
    activity: [
      { ts: now - 5 * DAY, text: 'Демо-пополнение выполнено' },
      { ts: now - 4 * DAY, text: 'Получены бонусные очки' },
      { ts: now - 2 * DAY, text: 'Демо-вывод выполнен' },
      { ts: now - 2 * DAY + 60_000, text: 'Открыт портфель' },
      { ts: now - DAY, text: 'Открыт раздел бонусов' },
    ],
    theme: 'brand',
  };
}

const isOp = (o) => o && typeof o.id === 'string' && ['deposit', 'withdraw'].includes(o.type)
  && Number.isFinite(o.amount) && o.amount > 0 && Number.isFinite(o.ts)
  && ['done', 'pending', 'declined', 'cancelled'].includes(o.status);

function isValid(data) {
  return data?.version === 1 && Array.isArray(data.ops) && data.ops.every(isOp)
    && Number.isFinite(data.points) && Number.isFinite(data.streak)
    && Array.isArray(data.activity) && data.done && data.claimed;
}

export function createStore(storageKey, storage = safeStorage()) {
  let state;
  try {
    const parsed = JSON.parse(storage?.getItem(storageKey) ?? 'null');
    state = isValid(parsed) ? parsed : seed(Date.now());
  } catch {
    state = seed(Date.now());
  }

  const listeners = new Set();
  const save = () => {
    try { storage?.setItem(storageKey, JSON.stringify(state)); } catch { /* приватный режим */ }
  };
  const commit = () => { save(); listeners.forEach((fn) => fn()); };

  const log = (text) => {
    state.activity.push({ ts: Date.now(), text });
    state.activity = state.activity.slice(-60);
  };

  const rollDay = () => {
    const today = dayKey();
    if (state.tasksDay === today) return false;
    state.tasksDay = today;
    state.done = {};
    state.claimed = {};
    return true;
  };

  const sum = (type, status = 'done') => state.ops
    .filter((o) => o.type === type && o.status === status)
    .reduce((total, o) => total + o.amount, 0);

  const round = (n) => Math.round(n * 100) / 100;

  const api = {
    get state() { return state; },
    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },

    totals() {
      const deposited = round(sum('deposit'));
      const withdrawn = round(sum('withdraw'));
      const reserved = round(sum('withdraw', 'pending'));
      const balance = round(deposited - withdrawn);
      return { deposited, withdrawn, reserved, balance, available: round(balance - reserved) };
    },

    /** Баланс на конец каждого из последних `days` дней. */
    history(days, now = Date.now()) {
      const end = new Date(now);
      end.setHours(23, 59, 59, 999);
      return Array.from({ length: days }, (_, i) => {
        const ts = end.getTime() - (days - 1 - i) * DAY;
        const value = state.ops
          .filter((o) => o.status === 'done' && o.ts <= ts)
          .reduce((total, o) => total + (o.type === 'deposit' ? o.amount : -o.amount), 0);
        return { ts: Math.min(ts, now), value: round(value) };
      });
    },

    validateAmount(type, raw) {
      const text = String(raw).replace(/\s/g, '').replace(',', '.');
      if (!text) return { error: 'Введи сумму' };
      if (!/^\d+(\.\d{1,2})?$/.test(text)) return { error: 'Только число, не больше двух знаков после запятой' };
      const amount = Number(text);
      if (amount < MIN_AMOUNT) return { error: `Минимум ${MIN_AMOUNT} ₽` };
      if (amount > MAX_AMOUNT) return { error: 'Максимум 1 000 000 ₽' };
      if (type === 'withdraw' && amount > api.totals().available) return { error: 'Столько нет на демо-балансе' };
      return { amount };
    },

    createOp(type, raw, method) {
      const check = api.validateAmount(type, raw);
      if (check.error) return check;
      const op = {
        id: `op-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
        type, amount: check.amount, status: 'pending', ts: Date.now(), method,
      };
      state.ops.unshift(op);
      log(type === 'deposit' ? 'Создана заявка на демо-пополнение' : 'Создана заявка на демо-вывод');
      commit();
      return { op };
    },

    cancelOp(id) {
      const op = state.ops.find((o) => o.id === id);
      if (!op || op.status !== 'pending') return false;
      op.status = 'cancelled';
      log('Демо-заявка отменена');
      commit();
      return true;
    },

    /** Имитирует обработку: переводит «созревшие» заявки в выполненные. */
    settle(now = Date.now()) {
      const ready = state.ops.filter((o) => o.status === 'pending' && now - o.ts >= PENDING_MS);
      ready.forEach((op) => {
        op.status = 'done';
        log(op.type === 'deposit' ? 'Демо-пополнение выполнено' : 'Демо-вывод выполнен');
        if (op.type === 'deposit') { rollDay(); state.done.deposit = true; }
      });
      if (ready.length) commit();
      return ready;
    },

    markTask(id) {
      rollDay();
      if (state.done[id]) return;
      state.done[id] = true;
      log(`Задание выполнено: ${TASKS.find((t) => t.id === id)?.title ?? id}`);
      commit();
    },

    claimTask(id) {
      rollDay();
      const task = TASKS.find((t) => t.id === id);
      if (!task || !state.done[id] || state.claimed[id]) return 0;
      state.claimed[id] = true;
      state.points += task.points;
      log(`Получено ${task.points} очков за задание`);
      commit();
      return task.points;
    },

    checkinStatus(now = Date.now()) {
      const today = dayKey(now);
      const yesterdayDate = new Date(now);
      yesterdayDate.setDate(yesterdayDate.getDate() - 1);
      const claimedToday = state.lastCheckin === today;
      const alive = claimedToday || state.lastCheckin === dayKey(yesterdayDate.getTime());
      const streak = alive ? state.streak : 0;
      // День цикла 0..6: уже полученный сегодня или тот, что можно получить сейчас.
      const index = claimedToday ? (streak - 1) % 7 : streak % 7;
      return { claimedToday, streak, index, reward: CHECKIN_REWARDS[index] };
    },

    checkin() {
      const status = api.checkinStatus();
      if (status.claimedToday) return 0;
      state.streak = status.streak + 1;
      state.lastCheckin = dayKey();
      state.points += status.reward;
      log(`Ежедневная отметка: +${status.reward} очков`);
      commit();
      return status.reward;
    },

    level() {
      const index = LEVELS.reduce((found, level, i) => (state.points >= level.from ? i : found), 0);
      const current = LEVELS[index];
      const next = LEVELS[index + 1] ?? null;
      const progress = next ? (state.points - current.from) / (next.from - current.from) : 1;
      return { index, current, next, progress };
    },

    refresh() { if (rollDay()) commit(); },
    setTheme(theme) { state.theme = theme; commit(); },
    reset() { const { theme } = state; state = { ...seed(Date.now()), theme }; commit(); },
  };
  return api;
}

function safeStorage() {
  try { return globalThis.localStorage ?? null; } catch { return null; }
}
