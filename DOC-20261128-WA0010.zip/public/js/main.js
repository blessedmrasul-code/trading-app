import { createStore } from './state.js';
import { html, mount, icon, toast, openSheet, closeSheet, refreshSheet, isSheetOpen, segmented, copyText } from './ui.js';
import {
  initTelegram, applyTheme, inTelegram, getUser, getStartParam, setBackButton, onBack, haptic, shareLink, verifySession,
} from './telegram.js';
import { renderHome, VERIFY_TEXT } from './views/home.js';
import { renderPortfolio, openAsset } from './views/portfolio.js';
import { renderWallet, openOperation, openOperationForm } from './views/wallet.js';
import { renderBonuses } from './views/bonuses.js';
import { renderPartners, referralLink } from './views/partners.js';
import { renderVip, openVipSoon } from './views/vip.js';

const PAGES = {
  home: ['Главная', renderHome],
  portfolio: ['Портфель', renderPortfolio],
  wallet: ['Кошелёк', renderWallet],
  bonuses: ['Бонусы', renderBonuses],
  partners: ['Партнёры', renderPartners],
  vip: ['VIP', renderVip],
};

const user = getUser();
const store = createStore(`nexora.demo.v1.${user?.id ?? 'guest'}`);

const ctx = {
  store,
  user,
  startParam: getStartParam(),
  verify: inTelegram ? 'checking' : 'outside',
  ui: { page: 'home', homePeriod: 30, portfolioPeriod: 90, segment: '', walletFilter: 'all', vipPlan: 90 },
  go,
};

const pageElement = (id) => document.getElementById(`page-${id}`);

function render() {
  const { page } = ctx.ui;
  PAGES[page][1](pageElement(page), ctx);
}

let enterTimer;
function go(page) {
  if (!PAGES[page]) return;
  const changed = ctx.ui.page !== page;
  ctx.ui.page = page;
  Object.keys(PAGES).forEach((id) => {
    const element = pageElement(id);
    element.hidden = id !== page;
    element.classList.remove('enter');
  });
  document.querySelectorAll('.tabbar button').forEach((button) => {
    if (button.dataset.go === page) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  document.getElementById('tabbar').style.setProperty('--tab', Object.keys(PAGES).indexOf(page));
  setBackButton(page !== 'home' || isSheetOpen());
  render();
  const element = pageElement(page);
  element.classList.add('enter');
  clearTimeout(enterTimer);
  enterTimer = setTimeout(() => element.classList.remove('enter'), 1200);
  if (changed) window.scrollTo(0, 0);
  // Задания «посетить раздел».
  if (page === 'portfolio' || page === 'vip') store.markTask(page);
}

function openProfile() {
  const draw = () => {
    const name = ctx.user ? [ctx.user.firstName, ctx.user.lastName].filter(Boolean).join(' ') : 'Гость';
    const [verifyLabel, verifyTone] = VERIFY_TEXT[ctx.verify];
    openSheet('Профиль', html`
      <dl class="facts">
        <div><dt>Имя</dt><dd>${name}</dd></div>
        ${ctx.user?.username && html`<div><dt>Username</dt><dd>@${ctx.user.username}</dd></div>`}
        ${ctx.user && html`<div><dt>Telegram ID</dt><dd class="num">${ctx.user.id}</dd></div>`}
        <div><dt>Проверка входа</dt><dd class="status ${verifyTone}">${verifyLabel}</dd></div>
      </dl>
      <h3>Оформление</h3>
      ${segmented('theme', [['brand', 'Тёмное NEXORA'], ['telegram', 'Как в Telegram']], store.state.theme, 'Тема оформления')}
      <h3>Демо-данные</h3>
      <p class="note">Операции и очки хранятся только на этом устройстве.</p>
      <button class="btn wide danger" data-action="reset-ask">Сбросить демо-данные</button>
    `, { onChange: draw });
  };
  draw();
  setBackButton(true);
}

function aboutDemo() {
  openSheet('Демонстрационный режим', html`
    <p>NEXORA сейчас показывает интерфейс на учебных данных.</p>
    <ul class="perks">
      <li>${icon('shield')}<span>Деньги не принимаются и не выплачиваются</span></li>
      <li>${icon('shield')}<span>Активы и курсы вымышлены</span></li>
      <li>${icon('shield')}<span>Очки и приглашения не имеют денежной ценности</span></li>
    </ul>
    <button class="btn primary wide" data-action="close-sheet">Понятно</button>
  `);
  setBackButton(true);
}

function dismissSheet() {
  closeSheet();
  setBackButton(ctx.ui.page !== 'home');
}

async function copyLink() {
  const ok = await copyText(referralLink(ctx.user));
  if (!ok) {
    toast('Не удалось скопировать. Нажми на ссылку и удерживай');
    haptic('error');
    return;
  }
  toast(ctx.user ? 'Ссылка скопирована' : 'Скопирован пример ссылки');
  haptic('success');
  store.markTask('invite');
}

const ACTIONS = {
  'about-demo': aboutDemo,
  profile: openProfile,
  'close-sheet': dismissSheet,
  deposit: () => openOperationForm('deposit', ctx),
  withdraw: () => openOperationForm('withdraw', ctx),
  op: ({ id }) => openOperation(id, ctx),
  'cancel-op': ({ id }) => { if (store.cancelOp(id)) toast('Заявка отменена'); },
  asset: ({ id }) => openAsset(id, ctx),
  segment: ({ value }) => { ctx.ui.segment = ctx.ui.segment === value ? '' : value; render(); },
  'home-period': ({ value }) => { ctx.ui.homePeriod = Number(value); render(); },
  'portfolio-period': ({ value }) => { ctx.ui.portfolioPeriod = Number(value); render(); },
  'wallet-filter': ({ value }) => { ctx.ui.walletFilter = value; render(); },
  'vip-plan': ({ value }) => { ctx.ui.vipPlan = Number(value); render(); },
  'vip-buy': () => openVipSoon(ctx.ui.vipPlan),
  checkin: () => {
    const reward = store.checkin();
    if (reward) { toast(`Начислено ${reward} очков`); haptic('success'); }
  },
  claim: ({ id }) => {
    const reward = store.claimTask(id);
    if (reward) { toast(`Начислено ${reward} очков`); haptic('success'); }
  },
  'copy-link': copyLink,
  'share-link': () => shareLink(referralLink(ctx.user), 'Открой NEXORA в Telegram'),
  theme: ({ value }) => { store.setTheme(value); applyTheme(value); refreshSheet(); },
  'reset-ask': () => openSheet('Сбросить демо-данные?', html`
    <p>Операции, очки и задания вернутся к начальному примеру.</p>
    <div class="duo"><button class="btn" data-action="close-sheet">Отмена</button><button class="btn danger" data-action="reset">Сбросить</button></div>
  `),
  reset: () => { dismissSheet(); store.reset(); toast('Демо-данные сброшены'); },
};

document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-action], [data-go]');
  if (!target || target.disabled) return;
  if (target.dataset.go) {
    if (isSheetOpen()) closeSheet();
    haptic('select');
    go(target.dataset.go);
    return;
  }
  const action = ACTIONS[target.dataset.action];
  if (!action) return;
  if (target.dataset.action.endsWith('period') || target.dataset.action.endsWith('filter') || target.dataset.action === 'vip-plan') haptic('select');
  action(target.dataset);
  if (isSheetOpen()) setBackButton(true);
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && isSheetOpen()) dismissSheet();
});

// Пока открыта клавиатура, нижнее меню не должно закрывать поле ввода.
document.addEventListener('focusin', (e) => document.body.classList.toggle('typing', e.target.matches('input:not([type="radio"])')));
document.addEventListener('focusout', () => document.body.classList.remove('typing'));

onBack(() => {
  if (isSheetOpen()) dismissSheet();
  else go('home');
});

function tick() {
  store.refresh();
  const settled = store.settle();
  if (settled.length) {
    toast(settled.length === 1
      ? `${settled[0].type === 'deposit' ? 'Демо-пополнение' : 'Демо-вывод'}: выполнено`
      : 'Демо-заявки выполнены');
  }
}

function start() {
  initTelegram();
  applyTheme(store.state.theme);

  mount(document.getElementById('tabbar'), html`
    <span class="tab-glow" aria-hidden="true"></span>
    ${Object.entries(PAGES).map(([id, [label]]) => html`<button data-go="${id}">${icon(id)}<span>${label}</span></button>`)}
  `);
  document.getElementById('avatar').textContent = (user?.firstName || 'N').slice(0, 1).toUpperCase();

  store.subscribe(() => { render(); refreshSheet(); });
  // Раздел из кнопки бота (?page=wallet) или из ссылки (?startapp=wallet).
  const requested = new URLSearchParams(location.search).get('page') || ctx.startParam;
  go(Object.hasOwn(PAGES, requested) ? requested : 'home');
  tick();
  setInterval(tick, 1000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { tick(); render(); } });

  verifySession().then((status) => {
    ctx.verify = status;
    render();
  });
}

start();
