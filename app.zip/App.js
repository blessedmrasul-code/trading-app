import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View, Text, ScrollView, TextInput, Pressable, StyleSheet, Linking, Alert, SafeAreaView, Platform, StatusBar as RNStatusBar,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Speech from 'expo-speech';
import D from './data.json';

const C = {
  bg: '#070b12', card: '#0f1726', card2: '#151f35', line: '#1d2a44', text: '#eaf0fb', muted: '#8996b2',
  up: '#16c784', down: '#ea3943', blue: '#5b8cff', gold: '#f0b90b',
};

/* ---------- хранилище ---------- */
async function load(key, def) {
  try { const v = await AsyncStorage.getItem(key); return v ? JSON.parse(v) : def; } catch (e) { return def; }
}
async function save(key, val) {
  try { await AsyncStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
}

/* ---------- данные практики ---------- */
const CHECK = [
  ['Тренд на старшем таймфрейме ясен', 'День или 4 часа: цена идёт вверх, вниз или в боковике?'],
  ['Рядом есть уровень', 'Поддержка, сопротивление или зона, от которой уже отскакивали.'],
  ['Стоп-лосс определён', 'Точная цена, а не «примерно там».'],
  ['Риск не больше 1–2% счёта', 'Размер позиции посчитан калькулятором.'],
  ['Цель минимум вдвое дальше стопа', 'Риск к прибыли не хуже 1:2.'],
  ['Я спокоен и не отыгрываюсь', 'Нет злости после убытка и нет страха упустить рост.'],
];
const QUIZ = [
  ['Стоп-лосс нужен, чтобы…', ['Гарантировать прибыль', 'Ограничить убыток заранее', 'Увеличить плечо', 'Убрать комиссии'], 1],
  ['Риск 1% на сделку при счёте 50 000 ₽ — это максимум…', ['500 ₽', '5 000 ₽', '1 000 ₽', '50 ₽'], 0],
  ['Риск к прибыли 1:2 означает…', ['Риск больше прибыли', 'Прибыль в 2 раза больше риска', 'Две сделки из одной', 'Плечо x2'], 1],
  ['Плечо…', ['Всегда полезно новичку', 'Увеличивает и прибыль, и убыток', 'Убирает комиссии', 'Гарантирует рост'], 1],
  ['После просадки 50% чтобы вернуться, нужно…', ['+50%', '+25%', '+100%', '+10%'], 2],
  ['Секретную фразу кошелька…', ['Можно отправить в поддержку', 'Можно сфотографировать в облако', 'Никому не показывать и не вводить на сайтах', 'Нужно написать в чат сигналов'], 2],
  ['Лучше пропустить сделку, если…', ['Нет стопа или нет уровня', 'Тренд понятен', 'Риск к прибыли 1:3', 'Риск 1%'], 0],
];
const FLAGS = [
  ['Гарантированный доход', 'Обещают «стабильно 5–10% в неделю» или «без риска». Гарантий на рынке нет.'],
  ['Просят секретную фразу или код из СМС', 'Настоящая поддержка биржи и кошелька этого не просит никогда.'],
  ['«Дай деньги, я поторгую за тебя»', 'Часто исчезают с деньгами или показывают поддельные отчёты.'],
  ['Скриншоты огромной прибыли', 'Скриншот легко нарисовать. Историю сделок не проверить.'],
  ['Сайт-двойник биржи', 'Адрес чуть изменён. Проверяй адрес и заходи по своей закладке.'],
  ['Давление «входи прямо сейчас»', 'Срочность нужна мошенникам. Нормальная сделка подождёт.'],
  ['Торговля на заёмные деньги', 'Не мошенник, но самый быстрый путь потерять счёт.'],
];

function fmt(x, d) {
  if (!isFinite(x)) return '—';
  const p = Math.pow(10, d);
  return String(Math.round(x * p) / p).replace('.', ',');
}
function splitSentences(text) {
  const m = text.match(/[^.!?]+[.!?]+[»")]*\s*|[^.!?]+$/g);
  return m ? m.map((s) => s.trim()).filter(Boolean) : [text];
}

/* ---------- мелкие компоненты ---------- */
function Card({ children, style }) { return <View style={[s.card, style]}>{children}</View>; }
function H({ children }) { return <Text style={s.h}>{children}</Text>; }
function Btn({ title, onPress, kind, small, disabled }) {
  return (
    <Pressable onPress={onPress} disabled={disabled}
      style={({ pressed }) => [s.btn, kind === 'green' && s.btnGreen, small && s.btnSmall, pressed && { opacity: 0.75 }, disabled && { opacity: 0.5 }]}>
      <Text style={[s.btnText, kind === 'green' && { color: '#03130c' }]}>{title}</Text>
    </Pressable>
  );
}
function Field({ label, value, onChange, keyboard }) {
  return (
    <View style={{ marginBottom: 10 }}>
      <Text style={s.label}>{label}</Text>
      <TextInput style={s.input} value={value} onChangeText={onChange} keyboardType={keyboard || 'default'}
        placeholderTextColor={C.muted} />
    </View>
  );
}
function Warn() {
  return (
    <Card style={{ backgroundColor: '#2a1d10', borderColor: '#5b3d12' }}>
      <Text style={{ color: '#f6d9a8', fontSize: 13, lineHeight: 19 }}>
        Важно. Торговля, особенно с плечом, может привести к потере всех вложенных денег. Приложение объясняет термины и обучает, оно не даёт финансовых советов. Не доверяй тем, кто обещает гарантированный доход, и никому не говори секретную фразу кошелька.
      </Text>
    </Card>
  );
}

/* ---------- экраны ---------- */
function Home({ go, bm, openBook }) {
  return (
    <ScrollView contentContainerStyle={s.pad}>
      <Text style={s.eyebrow}>ТРЕЙДИНГ С НУЛЯ</Text>
      <Text style={s.title}>Что значит каждый <Text style={{ color: C.up }}>знак</Text> на рынке</Text>
      <Text style={s.lead}>Короткая книга с озвучкой и закладкой, словарь, приложения и кошельки, калькулятор риска, чеклист, дневник и тест.</Text>
      {bm ? (
        <Card style={{ borderColor: '#16c78466' }}>
          <Text style={s.text}>Закладка: глава {bm.ch + 1} «{D.chapters[bm.ch] ? D.chapters[bm.ch].t : ''}»</Text>
          <View style={{ height: 10 }} />
          <Btn kind="green" title="Продолжить чтение" onPress={() => openBook(bm.ch)} />
        </Card>
      ) : null}
      <View style={s.tiles}>
        {[['Книга', 'читать и слушать', 'book'], ['Словарь', D.terms.length + ' терминов', 'terms'], ['Практика', 'калькулятор, тест', 'practice'], ['Ещё', 'сервисы, кошельки, FAQ', 'more']].map((t) => (
          <Pressable key={t[2]} style={s.tile} onPress={() => go(t[2])}>
            <Text style={s.tileT}>{t[0]}</Text>
            <Text style={s.tileS}>{t[1]}</Text>
          </Pressable>
        ))}
      </View>
      <Warn />
    </ScrollView>
  );
}

function Book({ startCh, setBm, bm }) {
  const [ch, setCh] = useState(startCh || 0);
  const [done, setDone] = useState([]);
  const [playing, setPlaying] = useState(false);
  const [cur, setCur] = useState(-1);
  const playRef = useRef(false);
  const chapter = D.chapters[ch];
  const sentences = useMemo(() => {
    const out = [];
    chapter.p.forEach((para, pi) => splitSentences(para).forEach((t) => out.push({ t, pi })));
    return out;
  }, [ch]);

  useEffect(() => { load('tp_done', []).then(setDone); }, []);
  useEffect(() => { setCh(startCh || 0); }, [startCh]);
  useEffect(() => () => { playRef.current = false; try { Speech.stop(); } catch (e) {} }, []);
  useEffect(() => { stop(); setCur(bm && bm.ch === ch ? bm.idx : -1); }, [ch]);

  function mark(i) {
    const b = { ch, idx: i };
    setBm(b); setCur(i); save('tp_bm', b);
  }
  function stop() {
    playRef.current = false; setPlaying(false);
    try { Speech.stop(); } catch (e) {}
  }
  function finishChapter() {
    setDone((d) => { if (d.indexOf(ch) >= 0) return d; const n = d.concat([ch]); save('tp_done', n); return n; });
  }
  function speakFrom(i) {
    if (!playRef.current) return;
    if (i >= sentences.length) { playRef.current = false; setPlaying(false); finishChapter(); return; }
    mark(i);
    try {
      Speech.speak(sentences[i].t, {
        language: 'ru-RU',
        onDone: () => speakFrom(i + 1),
        onError: () => { playRef.current = false; setPlaying(false); Alert.alert('Озвучка', 'Не удалось озвучить. Проверь звук и голос русского языка в настройках телефона.'); },
      });
    } catch (e) { playRef.current = false; setPlaying(false); }
  }
  function toggle() {
    if (playing) { stop(); return; }
    playRef.current = true; setPlaying(true);
    speakFrom(cur >= 0 && cur < sentences.length ? cur : 0);
  }

  let n = -1;
  return (
    <View style={{ flex: 1 }}>
      <ScrollView horizontal style={{ flexGrow: 0 }} contentContainerStyle={{ padding: 12 }} showsHorizontalScrollIndicator={false}>
        {D.chapters.map((c, i) => (
          <Pressable key={i} onPress={() => setCh(i)} style={[s.chip, i === ch && s.chipOn]}>
            <Text style={[s.chipT, i === ch && { color: '#03130c' }]}>{done.indexOf(i) >= 0 ? '✓ ' : ''}{i + 1}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <ScrollView contentContainerStyle={s.pad}>
        <Text style={s.eyebrow}>{D.bookTitle.toUpperCase()}</Text>
        <Text style={s.h}>{ch + 1}. {chapter.t}</Text>
        <Text style={s.hint}>Нажми на предложение, чтобы поставить закладку.</Text>
        {chapter.p.map((para, pi) => (
          <Text key={pi} style={s.read}>
            {splitSentences(para).map((t, k) => {
              n += 1; const idx = n;
              return (
                <Text key={k} onPress={() => { if (playing) stop(); mark(idx); }}
                  style={[idx === cur && s.sOn, bm && bm.ch === ch && bm.idx === idx && s.sMark]}>{t + ' '}</Text>
              );
            })}
          </Text>
        ))}
        <View style={{ height: 90 }} />
      </ScrollView>
      <View style={s.player}>
        <Btn small title="⏮" onPress={() => ch > 0 && setCh(ch - 1)} />
        <Btn small kind="green" title={playing ? '⏸ Пауза' : '▶ Слушать'} onPress={toggle} />
        <Btn small title="⏭" onPress={() => ch < D.chapters.length - 1 && setCh(ch + 1)} />
      </View>
    </View>
  );
}

function Terms() {
  const [q, setQ] = useState('');
  const list = D.terms.filter((t) => (t[0] + ' ' + t[1]).toLowerCase().indexOf(q.trim().toLowerCase()) >= 0);
  return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <H>Словарь</H>
      <TextInput style={s.input} value={q} onChangeText={setQ} placeholder="Найти: стоп-лосс, плечо, RSI…" placeholderTextColor={C.muted} />
      <View style={{ height: 12 }} />
      {list.map((t, i) => (
        <Card key={i}><Text style={s.cardT}>{t[0]}</Text><Text style={s.muted}>{t[1]}</Text></Card>
      ))}
      {!list.length ? <Text style={s.muted}>Ничего не нашлось.</Text> : null}
    </ScrollView>
  );
}

function RiskCalc() {
  const [dep, setDep] = useState('1000'); const [risk, setRisk] = useState('1');
  const [entry, setEntry] = useState('100'); const [stop, setStop] = useState('95'); const [target, setTarget] = useState('110');
  const n = (v) => parseFloat(String(v).replace(',', '.'));
  const d = n(dep), r = n(risk), e = n(entry), st = n(stop), t = n(target);
  let body;
  if (!(d > 0 && r > 0 && e > 0 && st > 0)) body = <Text style={s.muted}>Заполни счёт, риск, вход и стоп.</Text>;
  else if (e === st) body = <Text style={{ color: '#f6c177' }}>Вход и стоп не должны совпадать.</Text>;
  else {
    const long = st < e, money = d * r / 100, per = Math.abs(e - st), size = money / per, val = size * e;
    body = (
      <View>
        <Row a="Направление" b={long ? 'Лонг (покупка)' : 'Шорт (продажа)'} c={long ? C.up : C.down} />
        <Row a="Максимальный убыток по стопу" b={fmt(money, 2)} c={C.down} />
        <Row a="Размер позиции (штук)" b={fmt(size, 6)} />
        <Row a="Стоимость позиции" b={fmt(val, 2)} />
        {t > 0 && (long ? t > e : t < e) ? (
          <View>
            <Row a="Возможная прибыль у цели" b={fmt(Math.abs(t - e) * size, 2)} c={C.up} />
            <Row a="Риск к прибыли" b={'1 : ' + fmt(Math.abs(t - e) / per, 2)} />
          </View>
        ) : null}
        {val > d ? <Text style={s.warnT}>Позиция больше счёта: понадобится плечо. Новичку лучше уменьшить риск.</Text> : null}
        {r > 2 ? <Text style={s.warnT}>Риск больше 2% на сделку считается высоким.</Text> : null}
      </View>
    );
  }
  return (
    <Card>
      <Text style={s.cardT}>Калькулятор размера позиции</Text>
      <Field label="Размер счёта" value={dep} onChange={setDep} keyboard="decimal-pad" />
      <Field label="Риск на сделку, % от счёта" value={risk} onChange={setRisk} keyboard="decimal-pad" />
      <Field label="Цена входа" value={entry} onChange={setEntry} keyboard="decimal-pad" />
      <Field label="Цена стоп-лосса" value={stop} onChange={setStop} keyboard="decimal-pad" />
      <Field label="Цена цели (необязательно)" value={target} onChange={setTarget} keyboard="decimal-pad" />
      {body}
    </Card>
  );
}
function Row({ a, b, c }) {
  return (
    <View style={s.row}><Text style={[s.muted, { flex: 1 }]}>{a}</Text><Text style={{ color: c || C.text, fontWeight: '700' }}>{b}</Text></View>
  );
}
function Drawdown() {
  const [v, setV] = useState('30');
  const x = parseFloat(String(v).replace(',', '.'));
  return (
    <Card>
      <Text style={s.cardT}>Калькулятор просадки</Text>
      <Field label="Просадка, % от счёта" value={v} onChange={setV} keyboard="decimal-pad" />
      {x > 0 && x < 100 ? (
        <View>
          <Row a="Нужно заработать, чтобы вернуться" b={'+' + fmt((100 / (100 - x) - 1) * 100, 1) + '%'} c={C.up} />
          {x >= 30 ? <Text style={s.warnT}>Большая просадка: вернуться тяжело. Лучше уменьшать риск заранее.</Text> : null}
        </View>
      ) : <Text style={s.muted}>Укажи просадку от 0,1% до 99%.</Text>}
    </Card>
  );
}
function Checklist() {
  const [on, setOn] = useState([]);
  const all = on.length === CHECK.length;
  return (
    <Card>
      <Text style={s.cardT}>Чеклист перед сделкой</Text>
      {CHECK.map((c, i) => {
        const sel = on.indexOf(i) >= 0;
        return (
          <Pressable key={i} style={[s.check, sel && { borderColor: C.up }]} onPress={() => setOn(sel ? on.filter((x) => x !== i) : on.concat([i]))}>
            <Text style={{ color: sel ? C.up : C.muted, fontSize: 18, marginRight: 10 }}>{sel ? '☑' : '☐'}</Text>
            <View style={{ flex: 1 }}><Text style={s.text}>{c[0]}</Text><Text style={s.muted}>{c[1]}</Text></View>
          </Pressable>
        );
      })}
      <Text style={{ color: all ? C.up : '#ff8a8a', fontWeight: '700', marginTop: 8 }}>
        {all ? 'Все пункты отмечены: можно рассматривать вход по плану.' : 'Отмечено ' + on.length + ' из ' + CHECK.length + '. Пока лучше не входить.'}
      </Text>
    </Card>
  );
}
function Quiz() {
  const [ans, setAns] = useState({});
  const done = Object.keys(ans).length;
  let score = 0; QUIZ.forEach((q, i) => { if (ans[i] === q[2]) score++; });
  return (
    <Card>
      <Text style={s.cardT}>Тест: проверь себя</Text>
      {QUIZ.map((q, qi) => (
        <View key={qi} style={{ marginTop: 12 }}>
          <Text style={s.text}>{qi + 1}. {q[0]}</Text>
          {q[1].map((o, oi) => {
            const picked = ans[qi] !== undefined;
            const right = oi === q[2], mine = ans[qi] === oi;
            return (
              <Pressable key={oi} disabled={picked} onPress={() => setAns({ ...ans, [qi]: oi })}
                style={[s.opt, picked && right && { borderColor: C.up, backgroundColor: '#16c78422' }, picked && mine && !right && { borderColor: C.down, backgroundColor: '#ea394322' }]}>
                <Text style={s.text}>{o}</Text>
              </Pressable>
            );
          })}
        </View>
      ))}
      {done === QUIZ.length ? (
        <View style={{ marginTop: 12 }}>
          <Text style={{ color: score / QUIZ.length >= 0.7 ? C.up : '#ff8a8a', fontWeight: '800' }}>Результат: {score} из {QUIZ.length}</Text>
          <View style={{ height: 8 }} /><Btn small title="Пройти ещё раз" onPress={() => setAns({})} />
        </View>
      ) : null}
    </Card>
  );
}
function Journal() {
  const [list, setList] = useState([]);
  const [pair, setPair] = useState(''); const [note, setNote] = useState('');
  const [side, setSide] = useState('long'); const [res, setRes] = useState('win');
  useEffect(() => { load('tp_journal', []).then(setList); }, []);
  function add() {
    if (!pair.trim()) { Alert.alert('Дневник', 'Укажи инструмент, например BTC.'); return; }
    const d = new Date();
    const item = { pair: pair.trim(), note: note.trim(), side, res, date: d.getDate() + '.' + (d.getMonth() + 1) + '.' + d.getFullYear() };
    const n = list.concat([item]); setList(n); save('tp_journal', n); setPair(''); setNote('');
  }
  function del(i) {
    Alert.alert('Удалить запись?', '', [{ text: 'Нет' }, { text: 'Удалить', onPress: () => { const n = list.filter((_, k) => k !== i); setList(n); save('tp_journal', n); } }]);
  }
  const Seg = ({ val, cur, set, items }) => (
    <View style={{ flexDirection: 'row', gap: 6, marginBottom: 10 }}>
      {items.map((it) => (
        <Pressable key={it[0]} onPress={() => set(it[0])} style={[s.chip, cur === it[0] && s.chipOn]}><Text style={[s.chipT, cur === it[0] && { color: '#03130c' }]}>{it[1]}</Text></Pressable>
      ))}
    </View>
  );
  return (
    <Card>
      <Text style={s.cardT}>Дневник сделок</Text>
      <Text style={s.muted}>Записи хранятся только на этом телефоне.</Text>
      <View style={{ height: 10 }} />
      <Field label="Инструмент" value={pair} onChange={setPair} />
      <Seg cur={side} set={setSide} items={[['long', 'Лонг'], ['short', 'Шорт']]} />
      <Seg cur={res} set={setRes} items={[['win', 'Прибыль'], ['loss', 'Убыток'], ['be', 'Ноль']]} />
      <Field label="Ошибка или заметка" value={note} onChange={setNote} />
      <Btn kind="green" title="Сохранить сделку" onPress={add} />
      <View style={{ height: 10 }} />
      {list.slice().reverse().map((j, k) => {
        const i = list.length - 1 - k;
        return (
          <View key={i} style={s.jrow}>
            <View style={{ flex: 1 }}>
              <Text style={s.text}>{j.pair} · {j.side === 'short' ? 'Шорт' : 'Лонг'} · <Text style={{ color: j.res === 'win' ? C.up : j.res === 'loss' ? C.down : C.muted }}>{j.res === 'win' ? 'Прибыль' : j.res === 'loss' ? 'Убыток' : 'Ноль'}</Text></Text>
              <Text style={s.muted}>{j.date}{j.note ? ' · ' + j.note : ''}</Text>
            </View>
            <Btn small title="✕" onPress={() => del(i)} />
          </View>
        );
      })}
    </Card>
  );
}
function Practice() {
  return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <H>Практика</H>
      <RiskCalc /><Drawdown /><Checklist /><Journal /><Quiz />
    </ScrollView>
  );
}

function More() {
  const [tab, setTab] = useState('apps');
  const [open, setOpen] = useState(-1);
  const tabs = [['apps', 'Сервисы'], ['wallets', 'Кошельки'], ['faq', 'Ответы'], ['quotes', 'Цитаты'], ['books', 'Книги'], ['flags', 'Флаги']];
  return (
    <View style={{ flex: 1 }}>
      <ScrollView horizontal style={{ flexGrow: 0 }} contentContainerStyle={{ padding: 12 }} showsHorizontalScrollIndicator={false}>
        {tabs.map((t) => (
          <Pressable key={t[0]} onPress={() => { setTab(t[0]); setOpen(-1); }} style={[s.chip, tab === t[0] && s.chipOn]}>
            <Text style={[s.chipT, tab === t[0] && { color: '#03130c' }]}>{t[1]}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <ScrollView contentContainerStyle={s.pad}>
        {tab === 'apps' && D.apps.map((a, i) => (<Card key={i}><Text style={s.tag}>{a.cat}</Text><Text style={s.cardT}>{a.n}</Text><Text style={s.muted}>{a.d}</Text></Card>))}
        {tab === 'wallets' && D.wallets.map((a, i) => (<Card key={i}><Text style={s.tag}>{a.tag}</Text><Text style={s.cardT}>{a.n}</Text><Text style={s.muted}>{a.d}</Text></Card>))}
        {tab === 'faq' && D.faq.map((f, i) => (
          <Pressable key={i} onPress={() => setOpen(open === i ? -1 : i)}>
            <Card style={open === i ? { borderColor: '#16c78466' } : null}>
              <Text style={s.cardT}>{f.q}</Text>
              {open === i ? <Text style={[s.muted, { marginTop: 8, lineHeight: 21 }]}>{f.a}</Text> : null}
            </Card>
          </Pressable>
        ))}
        {tab === 'quotes' && D.quotes.map((q, i) => (<Card key={i}><Text style={[s.text, { fontSize: 16, lineHeight: 24 }]}>«{q.t}»</Text><Text style={{ color: C.gold, fontWeight: '700', marginTop: 8 }}>{q.a}</Text><Text style={s.muted}>{q.n}</Text></Card>))}
        {tab === 'books' && D.books.map((b, i) => (
          <Pressable key={i} onPress={() => Linking.openURL('https://www.google.com/search?q=' + encodeURIComponent(b.t + ' ' + b.a + ' книга')).catch(() => {})}>
            <Card><Text style={s.tag}>{b.lvl}</Text><Text style={s.cardT}>{b.t}</Text><Text style={s.muted}>{b.a} · {b.o}</Text><Text style={[s.muted, { marginTop: 6 }]}>{b.d}</Text></Card>
          </Pressable>
        ))}
        {tab === 'flags' && FLAGS.map((f, i) => (<Card key={i} style={{ borderLeftColor: C.down, borderLeftWidth: 3 }}><Text style={[s.cardT, { color: '#ff8a8a' }]}>{f[0]}</Text><Text style={s.muted}>{f[1]}</Text></Card>))}
        <View style={{ height: 20 }} />
        <Warn />
      </ScrollView>
    </View>
  );
}

/* ---------- защита от вылетов ---------- */
class Boundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(err) { return { err }; }
  render() {
    if (this.state.err) {
      return (
        <View style={{ flex: 1, backgroundColor: C.bg, padding: 24, justifyContent: 'center' }}>
          <Text style={{ color: C.text, fontSize: 20, fontWeight: '800' }}>Что-то пошло не так</Text>
          <Text style={{ color: C.muted, marginTop: 10 }}>Сфотографируй этот экран и отправь разработчику:</Text>
          <Text style={{ color: '#ff8a8a', marginTop: 10 }}>{String(this.state.err && this.state.err.message)}</Text>
          <View style={{ height: 16 }} />
          <Btn title="Попробовать снова" onPress={() => this.setState({ err: null })} />
        </View>
      );
    }
    return this.props.children;
  }
}

/* ---------- каркас ---------- */
const TABS = [['home', 'Главная', '⌂'], ['book', 'Книга', '📖'], ['terms', 'Словарь', '☰'], ['practice', 'Практика', '✎'], ['more', 'Ещё', '⋯']];

function Main() {
  const [tab, setTab] = useState('home');
  const [bm, setBm] = useState(null);
  const [startCh, setStartCh] = useState(0);
  useEffect(() => { load('tp_bm', null).then((b) => { if (b) setBm(b); }); }, []);
  function openBook(ch) { setStartCh(ch); setTab('book'); }
  return (
    <SafeAreaView style={s.root}>
      <StatusBar style="light" />
      <View style={s.top}><Text style={s.logo}>Подсказка<Text style={{ color: C.up }}>Трейдеру</Text></Text></View>
      <View style={{ flex: 1 }}>
        {tab === 'home' && <Home go={(t) => (t === 'book' ? openBook(bm ? bm.ch : 0) : setTab(t))} bm={bm} openBook={openBook} />}
        {tab === 'book' && <Book startCh={startCh} bm={bm} setBm={setBm} />}
        {tab === 'terms' && <Terms />}
        {tab === 'practice' && <Practice />}
        {tab === 'more' && <More />}
      </View>
      <View style={s.tabbar}>
        {TABS.map((t) => (
          <Pressable key={t[0]} style={s.tabBtn} onPress={() => { if (t[0] === 'book') setStartCh(bm ? bm.ch : startCh); setTab(t[0]); }}>
            <Text style={{ fontSize: 20, color: tab === t[0] ? C.up : C.muted }}>{t[2]}</Text>
            <Text style={{ fontSize: 11, color: tab === t[0] ? C.up : C.muted }}>{t[1]}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

export default function App() { return <Boundary><Main /></Boundary>; }

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: Platform.OS === 'android' ? (RNStatusBar.currentHeight || 0) : 0 },
  top: { paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.line },
  logo: { color: C.text, fontSize: 17, fontWeight: '800' },
  pad: { padding: 16, paddingBottom: 30 },
  eyebrow: { color: C.up, fontSize: 11, letterSpacing: 1.5, marginBottom: 8, fontWeight: '700' },
  title: { color: C.text, fontSize: 28, fontWeight: '800', lineHeight: 34, marginBottom: 12 },
  lead: { color: '#b4c0da', fontSize: 15, lineHeight: 22, marginBottom: 16 },
  h: { color: C.text, fontSize: 22, fontWeight: '800', marginBottom: 10 },
  hint: { color: C.muted, fontSize: 13, marginBottom: 12 },
  text: { color: C.text, fontSize: 15, lineHeight: 22 },
  read: { color: C.text, fontSize: 18, lineHeight: 30, marginBottom: 14 },
  sOn: { backgroundColor: '#5b8cff33' },
  sMark: { textDecorationLine: 'underline', textDecorationColor: C.gold },
  muted: { color: C.muted, fontSize: 14, lineHeight: 20 },
  warnT: { color: '#f6c177', marginTop: 8, fontSize: 13 },
  label: { color: C.muted, fontSize: 12, marginBottom: 4 },
  input: { backgroundColor: C.bg, borderColor: C.line, borderWidth: 1, borderRadius: 12, color: C.text, paddingHorizontal: 14, paddingVertical: 10, fontSize: 16 },
  card: { backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 18, padding: 16, marginBottom: 12 },
  cardT: { color: C.text, fontSize: 16, fontWeight: '700', marginBottom: 4 },
  tag: { color: C.muted, fontSize: 10, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 6 },
  btn: { backgroundColor: C.card2, borderColor: C.line, borderWidth: 1, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, alignItems: 'center' },
  btnGreen: { backgroundColor: C.up, borderColor: C.up },
  btnSmall: { paddingVertical: 9, paddingHorizontal: 14 },
  btnText: { color: C.text, fontWeight: '700', fontSize: 14 },
  tiles: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  tile: { width: '48%', backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 16, padding: 14 },
  tileT: { color: C.text, fontWeight: '800', fontSize: 15 },
  tileS: { color: C.muted, fontSize: 12, marginTop: 2 },
  chip: { backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 99, paddingHorizontal: 16, paddingVertical: 8, marginRight: 8 },
  chipOn: { backgroundColor: C.up, borderColor: C.up },
  chipT: { color: C.muted, fontWeight: '600' },
  row: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: C.card2, borderRadius: 12, padding: 12, marginTop: 6 },
  check: { flexDirection: 'row', alignItems: 'flex-start', borderColor: C.line, borderWidth: 1, borderRadius: 14, padding: 12, marginTop: 8 },
  opt: { borderColor: C.line, borderWidth: 1, borderRadius: 12, padding: 11, marginTop: 6, backgroundColor: C.card2 },
  jrow: { flexDirection: 'row', alignItems: 'center', gap: 8, borderTopColor: C.line, borderTopWidth: 1, paddingVertical: 10 },
  player: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', justifyContent: 'center', gap: 10, padding: 10, backgroundColor: '#101828f2', borderTopColor: C.line, borderTopWidth: 1 },
  tabbar: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.line, backgroundColor: '#0a101b' },
  tabBtn: { flex: 1, alignItems: 'center', paddingVertical: 8 },
});
